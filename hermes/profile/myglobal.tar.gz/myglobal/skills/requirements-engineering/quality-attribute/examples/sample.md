# Quality Attribute Examples

## Example: ChemTrack Quality Attributes

```markdown
# Quality Attribute Specifications: ChemTrack

**Version:** 1.0
**Date:** 2025-04-01

---

## Quality Attribute Trade-Off Matrix

|              | Performance | Security | Usability | Availability |
|--------------|-------------|----------|-----------|-------------|
| Performance  | --          | Sec wins | Perf wins | Avail wins  |
| Security     | Sec wins    | --       | Sec wins  | Sec wins    |
| Usability    | Perf wins   | Sec wins | --        | Avail wins  |
| Availability | Avail wins  | Sec wins | Avail wins| --          |

**Priority order:** Security > Availability > Performance > Usability
**Rationale:** Chemical safety data must be secure (regulatory mandate).
System must be available during lab hours (safety impact). Speed matters
for daily lab operations. Usability is desired but secondary.

---

## Quality Attribute Specifications

### QA-001: Search Response Time

- **Tag:** Response Time (Search Operations)
- **Ambition:** Search results appear fast enough that lab technicians
  do not lose their train of thought while working at the bench
- **Scale:** Seconds from submitting search query to complete results display
- **Meter:** Automated load test with 50 concurrent users against database
  of 50,000 chemical records; measured at 95th percentile
- **Past:** 4.2 seconds (current spreadsheet lookup with VLOOKUP)
- **Fail:** > 5 seconds (technicians revert to manual shelf-scanning)
- **Goal:** <= 2 seconds
- **Stretch:** <= 1 second
- **Wish:** <= 0.5 seconds (perception of instant response)
- **Source:** Lab Technician user class (Maria Santos), Usability workshop
- **Priority:** High
- **Traces to:** BO-1 (Reduce reporting time)
- **Constraints:** University network bandwidth (100 Mbps campus LAN)

### QA-002: System Availability

- **Tag:** Operational Availability
- **Ambition:** System available whenever labs are open for operation
- **Scale:** Percentage of scheduled operating hours system is accessible
- **Meter:** Uptime monitoring tool (e.g., Pingdom) checked every 60 seconds
  during scheduled hours (Mon-Fri 7:00-22:00, Sat 8:00-17:00)
- **Past:** N/A (new system; spreadsheets have no "uptime")
- **Fail:** < 95% (more than 4.5 hours downtime per week)
- **Goal:** >= 99.5% (30 min downtime per week max)
- **Stretch:** >= 99.9% (5 min downtime per week max)
- **Source:** EHS Compliance Officer (Tom Rivera)
- **Priority:** High
- **Traces to:** BO-4 (Reduce safety incidents)
- **Constraints:** IT department provides shared hosting; dedicated
  infrastructure not currently budgeted

### QA-003: Audit Trail Integrity

- **Tag:** Data Integrity (Audit Logging)
- **Ambition:** Every data modification is permanently and tamper-evidently
  logged for regulatory compliance
- **Scale:** Percentage of data modification events captured in audit log
  with full before/after values
- **Meter:** Quarterly audit: compare random sample of 100 modification
  events against audit log entries; verify completeness and immutability
- **Past:** N/A (no current audit trail)
- **Fail:** < 100% (any missed event is a compliance violation)
- **Goal:** 100% capture rate with tamper-evident storage
- **Source:** EHS Compliance Officer (Tom Rivera), DEA 21 CFR 1304
- **Priority:** Critical (regulatory)
- **Traces to:** BO-4 (Reduce safety incidents)

---

## Constraints

### CONST-001: University SSO Mandate
- **Type:** Technology
- **Statement:** All web applications must authenticate via the university's
  Active Directory SSO. No local user accounts permitted.
- **Source:** IT Security Policy (2024-07)
- **Impact:** Affects QA-003 (audit trail must capture AD user IDs),
  eliminates self-registration feature option

### CONST-002: WCAG 2.1 Compliance
- **Type:** Standard
- **Statement:** All user interfaces must comply with WCAG 2.1 Level AA
  accessibility guidelines.
- **Source:** University Accessibility Policy (federal Section 508)
- **Impact:** Affects usability attribute specifications and UI design
```

**Why this works:**
- Each attribute has all Planguage tags (Scale, Meter, Goal, Fail)
- Past baselines justify improvement targets
- Fail thresholds define unacceptable performance clearly
- Trade-off matrix makes conflict resolution explicit
- Constraints are documented separately from negotiable quality targets
- Everything traces to business objectives
