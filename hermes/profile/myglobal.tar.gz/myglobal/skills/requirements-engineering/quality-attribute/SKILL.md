---
name: quality-attribute
description: Specify non-functional requirements using Planguage notation with measurable scales, meters, goals, and trade-off analysis. Use when quality attributes like performance, security, or usability need quantified, testable specifications.
intent: >-
  Guide requirements engineers through a systematic process for identifying, prioritizing, and specifying quality attributes (non-functional requirements). Uses a five-step process from broad taxonomy to precise Planguage specifications with scale/meter/goal notation. Includes quality attribute trade-off analysis to make explicit which attributes take priority when they conflict (e.g., security vs. usability). Use this when vague NFRs like "the system shall be fast" need to become testable, measurable specifications.
type: component
theme: re-artifacts
best_for:
  - "Turning vague NFRs into measurable, testable specifications"
  - "Making explicit trade-offs between competing quality attributes"
  - "Specifying performance, security, availability, and usability targets"
scenarios:
  - "Stakeholders say the system must be 'fast' and 'secure' but I need actual numbers"
  - "Performance and usability are both 'critical' -- I need a framework to resolve the conflict"
estimated_time: "30-60 min"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['nfr', 'quality-attributes', 'planguage', 'a11y', 'accessibility']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Guide requirements engineers through identifying, prioritizing, and specifying quality attributes (non-functional requirements) with measurable targets. Uses Planguage notation for precise specification and a trade-off matrix for resolving conflicts between competing attributes.

This is not a checklist of generic NFRs to copy into your SRS. It is a process for discovering *which* quality attributes matter for *your* system and specifying them precisely enough to test.

## Key Concepts

### Quality Attribute Taxonomy

**External Quality Attributes** (visible to users):
| Attribute | Definition |
|-----------|-----------|
| Availability | Percentage of time the system is operational and accessible |
| Installability | Ease of installing the system in target environments |
| Integrity | Prevention of unauthorized data access or corruption |
| Interoperability | Ability to exchange data with other systems |
| Performance | Response time, throughput, and resource utilization under load |
| Reliability | Ability to perform without failure for a specified period |
| Robustness | Ability to handle invalid inputs, errors, and unexpected conditions gracefully |
| Safety | Ability to avoid states that cause harm to people or the environment |
| Security | Resistance to unauthorized access, data breaches, and malicious attacks |
| Usability | Ease of learning, efficiency of use, memorability, error frequency, satisfaction |

**Internal Quality Attributes** (visible to developers/maintainers):
| Attribute | Definition |
|-----------|-----------|
| Efficiency | Minimal use of system resources (CPU, memory, storage, bandwidth) |
| Modifiability | Ease of changing the system to meet new requirements |
| Portability | Ease of transferring to a new environment |
| Reusability | Components usable in other systems |
| Scalability | Ability to handle growth in users, data, or transactions |
| Verifiability | Ease of testing and validating the system |

### Planguage Notation
Tom Gilb's Planguage provides precise specification:

| Tag | Meaning | Example |
|-----|---------|---------|
| **Tag** | Name of the quality attribute | Response Time |
| **Ambition** | Qualitative goal statement | Fast enough that users do not perceive delay |
| **Scale** | Unit of measurement | Seconds from user action to system response |
| **Meter** | How to measure | Automated test harness under simulated load |
| **Goal** | Realistic target | 95th percentile response time <= 2 seconds |
| **Stretch** | Ideal target (exceeds goal) | 95th percentile response time <= 1 second |
| **Wish** | Aspirational (not committed) | 95th percentile response time <= 0.5 seconds |
| **Fail** | Unacceptable threshold | 95th percentile response time > 5 seconds |
| **Past** | Current baseline | 95th percentile response time = 4.2 seconds |

### Quality Attribute Trade-Off Matrix
When attributes conflict, make the trade-off explicit:

|              | Performance | Security | Usability | Availability |
|--------------|-------------|----------|-----------|-------------|
| Performance  | --          | Perf > Sec? | Perf > Usab? | Perf > Avail? |
| Security     |             | --       | Sec > Usab? | Sec > Avail? |
| Usability    |             |          | --        | Usab > Avail? |
| Availability |             |          |           | --          |

For each pair, stakeholders decide which attribute wins when they conflict. Document the decision and rationale.

### The Five-Step Quality Attribute Process

1. **Start with the broad taxonomy** -- Present the full list; do not define attributes in a vacuum
2. **Reduce the list** -- Identify which attributes actually matter for this system
3. **Prioritize** -- Rank the remaining attributes by importance
4. **Elicit expectations** -- For each priority attribute, discover stakeholder expectations
5. **Specify SMART requirements** -- Write measurable requirements using Planguage

### Anti-Patterns
- **The "Ilities" Dump** -- Copy-pasting 20 generic quality attributes into the SRS without analysis
- **Wishful Thinking** -- "99.999% availability" for a system that does not need (or cannot afford) it
- **Unmeasurable NFRs** -- "The system shall be user-friendly" (what does that mean? how do you test it?)

## Application

Use `template.md` for the fill-in structure.

### Step 1: Present the Taxonomy

Show stakeholders the full list of external and internal quality attributes. Ask:
- "Which of these are important for this system?"
- "Which of these could be a risk if we get them wrong?"
- "Which of these are competitors doing better than us?"

### Step 2: Reduce the List

From the full taxonomy, select 4-8 attributes that genuinely matter. Not every system needs all attributes:
- A medical device needs Safety and Reliability
- An e-commerce site needs Performance and Availability
- An internal tool needs Usability and Modifiability

### Step 3: Prioritize

Rank the selected attributes. Use pairwise comparison:
"If Performance and Security conflict, which wins?"

Document in a trade-off matrix.

### Step 4: Elicit Expectations

For each prioritized attribute, interview stakeholders:
- "What does 'fast enough' mean to you? Give me a number."
- "How much downtime is acceptable per month?"
- "What happens to the business if the system is down for 1 hour? 1 day?"
- "What is the current baseline for this attribute?"

### Step 5: Specify with Planguage

For each attribute, write a Planguage specification:

```markdown
### QA-001: Search Response Time

- **Tag:** Response Time (Search Operations)
- **Ambition:** Search results appear fast enough that lab technicians
  do not lose their train of thought
- **Scale:** Seconds from submitting search query to full results display
- **Meter:** Automated load test with 50 concurrent users, 50,000 chemical
  records, measured at 95th percentile
- **Past:** 4.2 seconds (current spreadsheet-based lookup)
- **Fail:** > 5 seconds (technicians will revert to manual lookup)
- **Goal:** <= 2 seconds
- **Stretch:** <= 1 second
- **Wish:** <= 0.5 seconds (instant feel)
- **Source:** Lab Technician user class (Maria Santos), Usability workshop
- **Priority:** High
- **Traces to:** BO-1 (Reduce reporting time)
```

### Step 6: Validate

- [ ] Each quality attribute has a measurable scale and meter
- [ ] Goal and Fail thresholds are defined (the boundaries that matter most)
- [ ] Trade-off decisions are documented and signed off by stakeholders
- [ ] Specifications are realistic given budget and technology constraints
- [ ] Each specification traces to a business objective

---

## Examples

See `examples/sample.md` for complete quality attribute specifications.

Mini example:

```markdown
### Quality Attribute Trade-Off Matrix (ChemTrack)

|              | Performance | Security | Usability | Availability |
|--------------|-------------|----------|-----------|-------------|
| Performance  | --          | Sec wins | Perf wins | Avail wins  |
| Security     | Sec wins    | --       | Sec wins  | Sec wins    |
| Usability    | Perf wins   | Sec wins | --        | Avail wins  |
| Availability | Avail wins  | Sec wins | Avail wins| --          |

**Priority order:** Security > Availability > Performance > Usability
**Rationale:** Chemical safety data must be secure (regulatory). System
must be available during lab hours (safety). Speed matters for daily use.
Usability is important but secondary to the above three.
```

## Common Pitfalls

### Pitfall 1: "The System Shall Be Fast"
**Symptom:** Vague quality attribute with no scale, meter, or target.

**Consequence:** Nobody knows when the requirement is met. Performance testing has no pass/fail criteria.

**Fix:** Use Planguage: define the scale (seconds), meter (how to measure), and goal (target number).

---

### Pitfall 2: Unrealistic Targets
**Symptom:** "99.999% availability" (five nines = 5.26 minutes downtime per year).

**Consequence:** Five-nines availability costs orders of magnitude more than three-nines. Budget does not support it.

**Fix:** Always pair targets with cost analysis. Ask: "What is the business cost of each hour of downtime?" and work backward to justify the investment.

---

### Pitfall 3: No Trade-Off Discussion
**Symptom:** All quality attributes are marked "High priority."

**Consequence:** When they inevitably conflict (security adds login friction, reducing usability), there is no decision framework.

**Fix:** Force pairwise trade-off decisions using the matrix. Every pair must have a winner documented.

---

### Pitfall 4: Quality Attributes as Afterthoughts
**Symptom:** Quality attributes added at the end of the SRS as an afterthought, after all functional requirements are written.

**Consequence:** Architecture decisions driven by functional requirements alone may be incompatible with quality attribute targets. Expensive rework.

**Fix:** Identify quality attributes during vision and scope. They influence architecture and should be known before detailed design.

## References

### Related Skills
- `the srs-document skill (separate)` -- Quality attributes are Section 6 of the SRS
- `../vision-and-scope/SKILL.md` -- Quality risks identified during vision and scope
- `../acceptance-criteria/SKILL.md` -- Quality attributes need testable acceptance criteria
- `the requirements-validation-process skill (separate)` -- Validating quality attribute feasibility

### External Frameworks
- Tom Gilb, *Competitive Engineering* (2005) -- Planguage notation
- Len Bass, Paul Clements, Rick Kazman, *Software Architecture in Practice* (2012) -- Quality attribute scenarios
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 14: Beyond Functionality
- ISO/IEC 25010:2011 -- Systems and software Quality Requirements and Evaluation (SQuaRE)

---

**Skill type:** Component
**Dependencies:** References `../vision-and-scope/SKILL.md`
**Used by:** `the srs-document skill (separate)`, `the requirements-validation-process skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
