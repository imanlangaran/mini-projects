# Quality Attribute Specification Template

Use this template to specify quality attributes using Planguage notation.

## Template

```markdown
# Quality Attribute Specifications: [Project Name]

**Version:** [x.y]
**Date:** [YYYY-MM-DD]

---

## Quality Attribute Trade-Off Matrix

|              | [Attr 1] | [Attr 2] | [Attr 3] | [Attr 4] |
|--------------|----------|----------|----------|----------|
| [Attr 1]     | --       | [Winner] | [Winner] | [Winner] |
| [Attr 2]     |          | --       | [Winner] | [Winner] |
| [Attr 3]     |          |          | --       | [Winner] |
| [Attr 4]     |          |          |          | --       |

**Priority order:** [Ranked list]
**Rationale:** [Why this ranking]

---

## Quality Attribute Specifications

### [QA-ID]: [Attribute Name]

- **Tag:** [Specific aspect being measured]
- **Ambition:** [Qualitative goal statement]
- **Scale:** [Unit of measurement]
- **Meter:** [How to measure -- test method, tool, conditions]
- **Past:** [Current baseline measurement]
- **Fail:** [Unacceptable threshold -- if exceeded, system fails to meet needs]
- **Goal:** [Realistic target]
- **Stretch:** [Ideal target, exceeds goal]
- **Wish:** [Aspirational, not committed]
- **Source:** [Who specified this, based on what evidence]
- **Priority:** [High / Medium / Low]
- **Traces to:** [Business objective ID]
- **Constraints:** [Factors that limit what is achievable]

*(Repeat for each quality attribute)*

---

## Constraints

### [CONST-ID]: [Constraint Name]
- **Type:** [Technology / Platform / Standard / Regulatory / Physical]
- **Statement:** [What is constrained and how]
- **Source:** [Origin of the constraint]
- **Impact:** [Which quality attributes or features are affected]
```

## Notes
- Every quality attribute must have at least Scale, Meter, Goal, and Fail.
- The trade-off matrix forces explicit conflict resolution -- do not skip it.
- Past (baseline) values help justify the investment in improvement.
- Constraints are not negotiable -- they bound the solution space.
