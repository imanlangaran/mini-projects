# Requirement Writing Examples

## Example 1: Event-Driven Requirement (Well-Written)

```markdown
## Requirement CT.INV.003

**EARS Pattern:** Event-Driven
**Priority:** High
**Source:** Interview with Lab Manager, 2024-01-15

### Requirement Statement
When the lab technician submits a new chemical entry, ChemTrack shall
validate the CAS number against the PubChem database and display
"Valid" or "Invalid CAS Number" within 3 seconds.

### Rationale
Manual CAS number entry caused 12% inventory discrepancies in 2023.

### Fit Criterion / Verification Method
- Submit a valid CAS number (e.g., 7732-18-5) --> system displays "Valid"
- Submit an invalid CAS number (e.g., 0000-00-0) --> system displays "Invalid CAS Number"
- Response time must be under 3 seconds

### Quality Self-Check
- [x] Correct -- Lab manager confirmed this matches their need
- [x] Feasible -- PubChem API is free and publicly available
- [x] Unambiguous -- Clear trigger, action, and response
- [x] Verifiable -- Test cases defined above
- [x] Modifiable -- Single behavior (validation on submit)
- [x] Traceable -- ID assigned, source documented
```

**Why this works:**
- Uses EARS event-driven pattern with a clear trigger
- Quantified response time ("within 3 seconds")
- Rationale explains the business problem (12% discrepancies)
- Fit criterion provides concrete test cases

---

## Example 2: Unwanted Behavior Requirement (Well-Written)

```markdown
## Requirement CT.INV.007

**EARS Pattern:** Unwanted Behavior
**Priority:** High
**Source:** Observation session, Lab Building A, 2024-02-03

### Requirement Statement
If the connection to the PubChem database is unavailable, then
ChemTrack shall allow the lab technician to save the chemical entry
with an "Unverified" CAS number status and shall queue the CAS number
for validation when the connection is restored.

### Rationale
Lab technicians observed working around network outages by recording
chemicals on paper, which introduced transcription errors.

### Fit Criterion / Verification Method
- Disconnect from PubChem; submit entry --> saves with "Unverified" status
- Restore connection --> queued CAS numbers are validated automatically
```

**Why this works:**
- Uses EARS unwanted behavior pattern with clear failure condition
- Provides a graceful degradation path (not just "display error")

---

## Example 3: Before and After (Rewriting a Weak Requirement)

**Before (weak):**
```
CT.ALERT.001: The system shall send appropriate alerts for chemicals.
```

**Problems:** "appropriate" is ambiguous, no trigger specified, not verifiable.

**After (strong, split into two requirements):**
```
CT.ALERT.001: When a chemical's expiration date is 30 days from today,
ChemTrack shall send an email alert to the lab technician assigned to
the chemical's storage location, containing the chemical name, CAS
number, location, and expiration date.

CT.ALERT.002: When a hazardous chemical's quantity exceeds the
maximum storage threshold for its location, ChemTrack shall send an
email alert to the Safety Officer within 5 minutes.
```

**Why the rewrite works:**
- Each requirement uses a specific EARS pattern
- Triggers are explicit
- Recipients are specific roles, not generic "users"

---

## Example 4: Positive vs. Negative Requirement

**Negative (acceptable for security):**
```
CT.SEC.005: The system shall not display chemical quantities or
locations to users who do not have the Inventory Viewer role.
```

**Positive (preferred for functional behavior):**
```
CT.INV.010: The system shall require a valid CAS number before
saving a new chemical record to the inventory.
```

*The negative form is acceptable for security constraints.
For functional behavior, the positive form is clearer.*
