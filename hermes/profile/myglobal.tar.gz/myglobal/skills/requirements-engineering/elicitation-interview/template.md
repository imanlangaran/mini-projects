# Interview Guide Template

Use this template to prepare for a requirements elicitation interview.

## Template

```markdown
# Interview Guide: [Project Name]

**Interviewee:** [Name, Role]
**Interviewer:** [Name]
**Date:** [YYYY-MM-DD]
**Duration:** [Planned duration, e.g., 60 min]
**Objective:** [What specific knowledge do you need from this interview?]

---

## Pre-Interview Preparation
- [ ] Reviewed existing documentation: [list documents reviewed]
- [ ] Identified stakeholder's user class: [user class]
- [ ] Shared agenda with stakeholder

## Context-Free Questions (10 min)
1. Can you describe your role and how you interact with [system/process]?
2. What are the biggest problems with the current [process/system]?
3. What would a successful solution look like to you?
4. Are there any constraints or regulations I should know about?

## Context-Specific Questions (30-40 min)

### Topic: [Topic 1, e.g., "Chemical Intake Process"]
5. Walk me through what happens when [specific event].
6. What information do you record at that point?
7. What happens when [exception or error condition]?
8. Tell me about the last time [specific problem] happened.

### Topic: [Topic 2, e.g., "Reporting and Compliance"]
9. [Question about this topic area]
10. [Follow-up about past behavior]

## Meta-Questions (5-10 min)
11. Is there anything I should have asked but did not?
12. Who else should I talk to about this?
13. Are there documents or artifacts I should review?

---

## Interview Notes

| Time | Topic | Notes | Tag |
|------|-------|-------|-----|
| | | | [PAIN/WORKAROUND/FREQ/IMPACT/WISH] |

## Follow-Up Actions
- [ ] Send summary to stakeholder by [date]
- [ ] Schedule follow-up for [open questions]
- [ ] Interview [additional stakeholder mentioned]

## Extracted Candidate Requirements
| Req ID | Requirement Statement | Source | Priority |
|--------|----------------------|--------|----------|
| | | This interview | |
```

## Notes
- Prepare 10-15 questions but follow interesting threads.
- Always send the summary within 48 hours for validation.
- Tag notes during the interview so extraction is faster afterward.
