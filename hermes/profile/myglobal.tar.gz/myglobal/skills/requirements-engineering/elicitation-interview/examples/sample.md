# Interview Examples

## Example 1: Well-Conducted Interview (Annotated)

```markdown
# Interview Guide: ChemTrack Chemical Inventory System

**Interviewee:** Dr. Sarah Chen, Lab Manager, Chemistry Department
**Interviewer:** Alex Rivera, Requirements Engineer
**Date:** 2024-01-15
**Duration:** 75 min
**Objective:** Understand chemical inventory pain points and reporting needs.

---

## Context-Free Questions

Q1: "Can you describe your role and how you interact with the
     current inventory process?"
A: "I oversee 3 labs with about 2,000 chemicals total. I approve
    purchases, manage compliance reporting, and deal with expired
    chemical disposal."

Q2: "What are the biggest problems with the current process?"
A: "Three things: (1) We find expired chemicals months late.
    (2) We cannot search by CAS number so we buy duplicates.
    (3) The monthly compliance report takes two full days."
    [PAIN] [FREQ: monthly] [IMPACT: 2 days labor]

## Context-Specific Questions

### Topic: Expiration Management

Q4: "Tell me about the last time someone found an expired chemical."
A: "Two weeks ago. A grad student found hydrochloric acid expired
    since October -- 3 months late. Emergency disposal cost $800."
    [PAIN] [IMPACT: $800] [WORKAROUND: weekly manual check]

Q5: "How do you currently track expiration dates?"
A: "Each technician has a spreadsheet. They check weekly, but it slips."
    [WORKAROUND: manual spreadsheet]

### Topic: Search and Duplicate Prevention

Q7: "When you need to find a specific chemical, what do you do today?"
A: "I open each lab's spreadsheet and Ctrl+F. The naming is inconsistent
    -- Lab A uses 'Hydrochloric Acid' and Lab B uses 'HCl.'"
    [PAIN] [WORKAROUND: Ctrl+F across multiple files]

Q8: "Tell me about a time you purchased a chemical you already had."
A: "Last quarter we ordered sodium hydroxide for Lab A, but Lab B
    had 5 kilos on the shelf. $200 wasted. Happens monthly."
    [IMPACT: ~$200/month] [FREQ: monthly]

## Meta-Questions

Q14: "Is there anything I should have asked but did not?"
A: "You did not ask about compliance. Annual EPA reporting for
     hazardous chemicals is a huge pain point too."

## Extracted Candidate Requirements
| Req ID | Requirement Statement | Source | Priority |
|--------|----------------------|--------|----------|
| CT.ALERT.001 | When chemical is 30 days from expiration, send email to assigned technician | Q4 | High |
| CT.SEARCH.001 | Allow search by chemical name, CAS number, location | Q7 | High |
| CT.INV.003 | Validate CAS number on entry | Q7, Q8 | High |
| CT.RPT.001 | Generate monthly compliance report | Q2, Q14 | Medium |
```

**Why this works:**
- Questions progress from broad to specific (past behavior)
- Notes are tagged for easy extraction
- Concrete data captured (costs, frequencies, specific incidents)
- Candidate requirements trace directly to specific answers

---

## Example 2: Common Mistakes in Interview Technique

```markdown
**Bad: Leading question**
Q: "Would an automatic alert system help you manage expirations?"
A: "Yes, definitely."
--> Stakeholder agreed with your suggestion. This tells you nothing.

**Good: Past-behavior question**
Q: "Tell me about the last time an expired chemical caused a problem."
A: [Provides specific story with costs, timeline, and workaround]
--> Real data to derive requirements from.

**Bad: Hypothetical feature question**
Q: "Would you use a mobile app to scan chemical barcodes?"
A: "Sure, that sounds cool."
--> "Sounds cool" is not a requirement.

**Good: Workflow question**
Q: "Walk me through what happens when a new chemical shipment arrives."
A: "The technician opens the box, checks the packing slip, and enters
    each chemical one by one. Takes about 20 minutes per shipment."
--> Now you know the actual workflow and the data entry bottleneck.
```
