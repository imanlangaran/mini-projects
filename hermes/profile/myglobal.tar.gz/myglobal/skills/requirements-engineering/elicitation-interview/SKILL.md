---
name: elicitation-interview
description: Plan and conduct stakeholder interviews that uncover real requirements using structured question progressions. Use when you need to elicit requirements directly from users, sponsors, or domain experts.
intent: >-
  Plan and conduct requirements elicitation interviews that move from broad context questions to specific behavioral questions, using active listening and past-behavior techniques to uncover real needs rather than hypothetical wishes. Covers interview preparation, question categories (context-free, context-specific, meta-questions), the "Mom Test" principle of asking about past behavior, and techniques for capturing and validating interview notes.
type: component
theme: re-artifacts
best_for:
  - "Eliciting requirements from stakeholders through structured conversation"
  - "Uncovering unstated needs and assumptions through targeted questioning"
  - "Building rapport with domain experts while gathering precise requirements"
scenarios:
  - "I need to interview the lab manager about their chemical inventory needs but do not know where to start"
  - "My stakeholder interviews keep producing vague wish lists instead of concrete requirements"
  - "I want a reusable interview guide template for requirements elicitation"
estimated_time: "30-60 min preparation, 45-90 min per interview"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['elicitation', 'interview', 'questions', 'stakeholder']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Plan and conduct stakeholder interviews that uncover real requirements through structured question progressions and active listening. The goal is to move from the stakeholder's world (their problems, workflow, constraints) to specific system behaviors -- without leading them toward a predetermined solution.

This is not about running a workshop (see `../requirements-elicitation-workshop/SKILL.md`) or designing a questionnaire for large audiences (see `the questionnaire-design skill (separate)`). Interviews work best for deep exploration with 1-3 stakeholders at a time.

## Key Concepts

### Three Categories of Interview Questions

**1. Context-Free Questions (The Big Picture)**
Asked early in the project or when meeting a stakeholder for the first time. They reveal the problem space without assuming a solution.

- "Who are the users of this system?"
- "What problems does the current process have?"
- "What would a successful solution look like to you?"
- "Are there any constraints I should know about?"

**2. Context-Specific Questions (The Details)**
Asked after the big picture is understood. They drill into specific workflows, data, rules, and exceptions.

- "Walk me through what happens when a new chemical shipment arrives."
- "What information do you record for each chemical?"
- "What happens when a chemical expires?"
- "How do you handle chemicals that fail quality inspection?"

**3. Meta-Questions (The Interview About the Interview)**
Asked to assess the quality of the elicitation process itself.

- "Is there anything I should have asked but did not?"
- "Who else should I talk to about this?"
- "Are there documents I should review?"
- "How confident are you in the answers you gave today?"

### The "Mom Test" Principle
Named after Rob Fitzpatrick's concept: your mom will tell you your idea is great because she loves you. Similarly, stakeholders will agree with leading questions. The fix is to ask about **past behavior**, not hypotheticals.

| Bad (Hypothetical) | Good (Past Behavior) |
|-------------------|---------------------|
| "Would you use a barcode scanner for chemical intake?" | "How do you currently record chemicals when a shipment arrives?" |
| "Do you think an alert system would help?" | "Tell me about the last time a chemical expired before anyone noticed." |
| "Would it be useful to search by CAS number?" | "When you need to find a specific chemical, what do you do?" |
| "Would you like automated reports?" | "How do you create the monthly inventory report today?" |

**Rule:** If the stakeholder has never struggled with the problem you are asking about, the feature may not be necessary.

### Why This Works
- **Context-free questions first** prevent you from anchoring on a solution before understanding the problem
- **Past-behavior questions** reveal what people actually do, not what they think they would do (people are poor predictors of their own future behavior)
- **Meta-questions** catch blind spots -- stakeholders often know more than they think to say unprompted

### Anti-Patterns
- **The Leading Question** -- "You would want the system to send alerts, right?" The stakeholder will agree with anything phrased this way.
- **The Solution Interview** -- "Let me describe the system and you tell me if you like it." This is a demo, not elicitation.
- **The Interrogation** -- Rapid-fire questions with no listening. The stakeholder shuts down.
- **The Wish List Collector** -- "What features do you want?" produces a laundry list without priorities or rationale.

## Application

Use `template.md` for the interview guide structure.

### Step 1: Prepare the Interview

**Before the interview:**
1. Identify the stakeholder's role and perspective (user, sponsor, domain expert, regulator)
2. Review existing documentation (current system, process maps, prior interviews)
3. Define the interview objective -- what specific knowledge do you need?
4. Draft 10-15 questions organized by category (context-free, context-specific, meta)
5. Estimate time allocation: 10 min context-free, 25-40 min context-specific, 5-10 min meta
6. Share the agenda (not the questions) with the stakeholder in advance

**Logistics:**
- Schedule 60-90 minutes (45 min minimum for meaningful depth)
- Two interviewers if possible: one asks, one takes notes
- Request permission to record (audio) as backup

### Step 2: Open the Interview

1. Thank the stakeholder for their time
2. State the purpose: "We are gathering requirements for [project]. Your input shapes what we build."
3. Set expectations: "I will ask about your current work, pain points, and needs. There are no wrong answers."
4. Confirm recording permission if applicable
5. Start with a rapport question: "Can you describe your role and how you interact with the current process?"

### Step 3: Progress Through Question Categories

**Funnel approach -- broad to specific:**

```
[Context-Free] "What are the biggest problems with the current chemical inventory process?"
       |
       v
[Context-Specific] "You mentioned expired chemicals. Walk me through what happens
                    when you discover an expired chemical in the lab."
       |
       v
[Follow-Up] "How often does that happen? What is the impact when it does?"
       |
       v
[Past Behavior] "Tell me about the last time this happened. What did you do?"
```

**Active listening techniques during the interview:**
- **Paraphrase** -- "So if I understand correctly, you currently check expiration dates manually each Friday?"
- **Reflect** -- "It sounds like the manual process is frustrating because it takes 2 hours."
- **Probe** -- "You mentioned workarounds. Can you tell me more about that?"
- **Silence** -- After an answer, wait 3-5 seconds. Stakeholders often add important details in the pause.

### Step 4: Capture Requirements Indicators

During the interview, listen for these signals:
- **Pain points** -- "The worst part is..." --> potential requirement
- **Workarounds** -- "What I do instead is..." --> current process gap
- **Frequency** -- "This happens every day" --> priority indicator
- **Impact** -- "When this fails, we lose..." --> business value
- **Wishes** -- "I wish the system could..." --> candidate feature (validate with past behavior)

Mark each note with a category tag: `[PAIN]`, `[WORKAROUND]`, `[FREQ]`, `[IMPACT]`, `[WISH]`

### Step 5: Close and Validate

In the final 10 minutes:
1. Summarize the top 3-5 things you heard: "The key points I captured are..."
2. Ask the meta-questions: "Is there anything I missed? Who else should I talk to?"
3. Confirm next steps: "I will send you a summary within 2 days for your review."
4. Thank them again and indicate how their input will be used

### Step 6: Process Interview Notes

Within 24 hours:
1. Review and organize notes by topic area
2. Extract candidate requirements (tag each with source: "Interview, [Name], [Date]")
3. Identify gaps and follow-up questions
4. Send a summary to the stakeholder for validation
5. File notes for traceability (see `../requirements-traceability/SKILL.md`)

---

## Examples

See `examples/sample.md` for a complete interview guide and annotated interview transcript.

Mini example excerpt:

```markdown
**Context-Free:**
Q: "What are the top 3 problems with the current chemical inventory process?"
A: "Expired chemicals sitting on shelves, no way to search by CAS number,
    and the monthly report takes two days to compile manually."

**Context-Specific (following up on expired chemicals):**
Q: "Walk me through the last time someone found an expired chemical."
A: "Two weeks ago, a grad student found expired hydrochloric acid during
    a routine lab check. It had been expired for 3 months. We had to
    initiate an emergency disposal. Cost us $800 and half a day."

**Extracted Requirement:**
CT.ALERT.001: When a chemical is 30 days from expiration, ChemTrack
shall send an email to the assigned lab technician. [Source: Lab Manager
interview, 2024-01-15; Pain: $800 disposal cost from late detection]
```

## Common Pitfalls

### Pitfall 1: Leading the Witness
**Symptom:** "You would want automatic alerts, right?" Every question implies the answer.

**Consequence:** You get confirmation of your assumptions, not the stakeholder's real needs.

**Fix:** Use open-ended questions and past-behavior probes. Never embed the expected answer in the question.

---

### Pitfall 2: Skipping Preparation
**Symptom:** Showing up without reviewing existing documentation or preparing questions.

**Consequence:** You waste the stakeholder's time asking questions already answered in existing materials. You miss the chance to go deeper.

**Fix:** Always review available documentation beforehand. Prepare at least 10 questions. Draft follows context-free to context-specific progression.

---

### Pitfall 3: Not Validating Notes
**Symptom:** Interview notes are never sent back to the stakeholder for confirmation.

**Consequence:** Misunderstandings become requirements. The stakeholder said "weekly" and the analyst heard "daily."

**Fix:** Send a written summary within 48 hours. Ask the stakeholder to confirm or correct.

---

### Pitfall 4: Interviewing Only Power Users
**Symptom:** All interviews are with managers or experts. Infrequent users and novices are ignored.

**Consequence:** The system is designed for experts. New users struggle, and edge cases from occasional use are missed.

**Fix:** Interview across user classes: frequent users, infrequent users, managers, administrators. Each has different needs.

---

### Pitfall 5: Recording Wishes as Requirements
**Symptom:** "I wish I could see a dashboard" becomes "The system shall display a dashboard" without validation.

**Consequence:** Scope creep with features nobody actually needs frequently.

**Fix:** For every wish, ask: "How often would you use that? What do you do today instead?" Validate with past behavior before promoting to a requirement.

## References

### Related Skills
- `../requirements-elicitation-workshop/SKILL.md` -- Group elicitation for multiple stakeholders simultaneously
- `the questionnaire-design skill (separate)` -- Scaling elicitation to larger audiences via surveys
- `the observation-analysis skill (separate)` -- Observing users in their environment to complement interviews
- `../stakeholder-analysis/SKILL.md` -- Identifying whom to interview and their perspectives
- `../writing-requirements/SKILL.md` -- Turning interview findings into well-written requirements

### External Frameworks
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 7: Requirements Elicitation
- Rob Fitzpatrick, *The Mom Test* (2013) -- Asking about past behavior instead of hypotheticals
- Steve Portigal, *Interviewing Users* (2013) -- Active listening and rapport-building techniques

---

**Skill type:** Component
**Dependencies:** `../stakeholder-analysis/SKILL.md`
**Used by:** `../requirements-elicitation-workshop/SKILL.md`, `the requirements-analysis-process skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
