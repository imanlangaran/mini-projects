# Requirements Review Advisor Example

## Example: ChemTrack Review Planning

```markdown
## Context
ChemTrack SRS v1.0 is complete with 35 functional requirements, 8
quality attributes, and 12 business rules. The system manages chemical
inventory with regulatory compliance (EHS/EPA). Team: 1 BA, 2
developers, 1 tester, 1 EHS domain expert.

## Selection Answers

**Q1: Risk level?** Business-critical (regulatory compliance; violations 
can result in fines and license issues)

**Q2: What is being reviewed?** Full SRS (~45 pages)

**Q3: Resources available?** Full team (BA, 2 developers, tester, domain expert)

## Recommended Approach: Formal Fagan Inspection

### Rationale
Business-critical system with regulatory implications. Formal inspection
provides the highest defect detection rate and creates an audit trail
for compliance documentation.

### Inspection Plan

**Roles:**
- Moderator: Senior Developer (experienced with inspections)
- Author: BA (Sarah Chen)
- Inspectors: Developer 2, Tester, EHS Officer (domain expert)
- Reader: Tester (reads requirements aloud during meeting)

**Schedule (3 inspection sessions):**

| Session | Scope | Pages | Prep Time | Meeting Time |
|---------|-------|-------|-----------|-------------|
| 1 | Sections 1-3 (Intro, Overall Description, Features 3.1-3.2) | 15 pages | 2 hours/inspector | 2 hours |
| 2 | Sections 3.3-5 (Features 3.3-3.6, Data Reqs, Interfaces) | 18 pages | 2.5 hours/inspector | 2.5 hours |
| 3 | Sections 6-8 (Quality Attributes, Constraints, Appendices) | 12 pages | 1.5 hours/inspector | 1.5 hours |

**Defect Checklist (Tailored to ChemTrack):**
- [ ] Regulatory rules cited with specific CFR/regulation reference
- [ ] Chemical quantities always paired with units (no bare numbers)
- [ ] CAS number format specified consistently
- [ ] All alert timing values are explicit (not "timely" or "promptly")
- [ ] Every "shall" statement is testable by QA
- [ ] No implementation details in requirements (e.g., "use PostgreSQL")
- [ ] Quality attributes have Planguage specifications (Scale, Meter, Goal, Fail)
- [ ] Business rules referenced by BR-ID, not restated inline

**Entry Criteria (for each session):**
- Materials distributed at least 3 business days before meeting
- All inspectors confirm preparation is complete
- Author confirms no known open issues in the scope

**Exit Criteria:**
- All defects logged and classified
- Rework owner (author) assigned for each defect
- Decision: Accept / Accept with rework / Re-inspect

### Expected Results
Based on industry data for formal inspections:
- Expected defect detection: 60-80% of defects in reviewed material
- Expected defect rate: 5-10 defects per hour of meeting time
- Expected total: 30-60 defects found across 3 sessions
- ROI: Each defect found saves estimated 4-8 hours of downstream
  rework (if found during development/testing)
```

**Why this works:**
- Formal inspection justified by business-critical risk level
- Manageable session sizes (12-18 pages each, not 45 pages at once)
- Tailored defect checklist adds domain-specific checks
- Clear roles, schedule, entry/exit criteria
- Expected results provide a baseline for measuring review effectiveness
