---
name: requirements-review-advisor
description: Choose and plan a requirements review approach, from informal walkthroughs to formal Fagan inspections. Use when deciding how rigorously to review requirements and structuring the review process for maximum defect detection.
intent: >-
  Guide requirements engineers in selecting the right review approach (informal review, walkthrough, or formal inspection) and planning the review process. Covers the Fagan inspection method with its six stages (planning, overview, preparation, meeting, rework, follow-up), defect checklists for requirements, and metrics for review effectiveness. Use this when requirements are ready for review and you need to choose the right level of rigor based on project risk, available resources, and quality goals.
type: interactive
theme: re-process
best_for:
  - "Selecting the right review formality level for a project"
  - "Planning and conducting formal requirements inspections"
  - "Creating defect checklists tailored to your requirements"
scenarios:
  - "Requirements are drafted and I need to plan the review. What process should I use?"
  - "We have a safety-critical system. How should we inspect the requirements?"
  - "Our reviews never find real issues -- how do I make them more effective?"
estimated_time: "10-15 min for planning; review execution time varies"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['review', 'fagan', 'inspection', 'validation']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Guide requirements engineers in selecting the right review approach and planning the review process. Use this to maximize defect detection before requirements are implemented, when fixing defects costs 10-100x less than fixing them in code.

This is not about reviewing code. It is about reviewing requirements -- catching ambiguity, incompleteness, inconsistency, and infeasibility before developers start building.

## Key Concepts

### Review Formality Spectrum

| Level | Formality | Effort | Defect Detection | Best For |
|-------|-----------|--------|-----------------|---------|
| **Ad-hoc Review** | Minimal | Lowest | Low (20-30%) | Minor changes, low-risk features |
| **Peer Desk Check** | Low | Low | Moderate (30-40%) | Individual requirements, quick feedback |
| **Walkthrough** | Moderate | Medium | Good (40-60%) | Requirements presentations, team alignment |
| **Formal Inspection** | High | High | Best (60-80%) | Critical systems, regulatory compliance |

### The Fagan Inspection Process

Six stages, each with defined entry and exit criteria:

1. **Planning** -- Moderator selects inspectors, distributes materials, schedules meeting
2. **Overview** -- Author presents the requirements context (skip if inspectors are already familiar)
3. **Preparation** -- Each inspector reviews independently, logs potential defects (this is where most defects are found)
4. **Meeting** -- Inspectors consolidate findings, identify new issues through discussion, classify defects
5. **Rework** -- Author addresses all identified defects
6. **Follow-up** -- Moderator verifies all defects are resolved, decides if re-inspection is needed

### Requirements Defect Taxonomy

| Defect Type | Description | Example |
|------------|-------------|---------|
| **Ambiguity** | Multiple interpretations possible | "The system shall respond quickly" |
| **Incompleteness** | Missing information or scenarios | No error handling specified |
| **Inconsistency** | Contradicts another requirement | FR-10 says "always," FR-45 says "except when..." |
| **Infeasibility** | Technically or economically impossible | "100% uptime with zero cost" |
| **Unverifiability** | Cannot be tested | "The system shall be user-friendly" |
| **Duplication** | Same requirement stated differently in two places | FR-12 and FR-78 say the same thing |
| **Gold-plating** | Requirement not traced to any business need | Feature nobody asked for |
| **Design in requirements** | Implementation specified instead of behavior | "Use PostgreSQL with a B-tree index" |

### Review Metrics

| Metric | Target | What It Means |
|--------|--------|--------------|
| **Preparation rate** | 1-2 pages/hour | How fast inspectors review during preparation |
| **Defect detection rate** | 5-10 defects/hour of meeting | Effectiveness of the inspection meeting |
| **Inspection rate** | 2-4 pages/hour during meeting | Speed of the inspection meeting |
| **Rework rate** | < 20% of original effort | How much rework results from the inspection |

## Application

### Interactive Selection Process

**Question 1: What is the risk level of this system?**

1. **Safety-critical** -- Failure could cause harm to people or environment
2. **Business-critical** -- Failure causes significant financial loss or regulatory violation
3. **Standard** -- Failure causes inconvenience but no serious consequences
4. **Low-risk** -- Internal tool, non-critical, easily recoverable

---

**Question 2: What is being reviewed?**

1. **Full SRS** -- Complete requirements specification (50+ pages)
2. **Requirement set** -- A section or feature's requirements (5-20 pages)
3. **Individual requirements** -- A few requirements or user stories
4. **Requirements changes** -- Modified requirements for an existing baseline

---

**Question 3: What resources are available for the review?**

1. **Full team** -- BA, developers, testers, domain expert available for reviews
2. **Partial team** -- BA and 1-2 others available
3. **Minimal** -- Just the BA and one reviewer
4. **Time-constrained** -- Need to review quickly (< 1 day)

---

### Recommendation Logic

**If safety/business-critical + full SRS + full team:**
Recommend: **Formal Fagan Inspection**
- Maximum defect detection for highest-risk situations
- Plan 2-4 inspection sessions (review in chunks, not all at once)
- Use full defect checklist
- Track metrics for process improvement

**If safety-critical + any review scope + any team:**
Recommend: **Formal Fagan Inspection (mandatory)**
- Safety-critical systems should always use formal inspection regardless of constraints
- If team is limited, conduct inspection in smaller chunks over more sessions
- Regulatory compliance often requires documented inspection evidence

**If standard + full SRS + full/partial team:**
Recommend: **Structured Walkthrough**
- Author presents requirements section by section
- Reviewers ask questions and note issues
- Less overhead than formal inspection, still effective
- Focus walkthrough time on highest-risk sections

**If standard + requirement set + partial team:**
Recommend: **Peer Desk Check + Focused Walkthrough**
- Peer desk check for individual requirement quality
- Short walkthrough (1-2 hours) for the full set
- Use abbreviated defect checklist

**If low-risk + individual requirements + minimal team:**
Recommend: **Peer Desk Check**
- One reviewer reads requirements and provides feedback
- Focus on the 7 characteristics: complete, correct, feasible, necessary, prioritized, unambiguous, verifiable
- Informal, fast, still better than no review

**If requirements changes:**
Recommend: **Focused Review**
- Review only the changed requirements
- Check for side effects on existing requirements
- Verify traceability is updated
- Level of formality matches the original review level

---

### Defect Checklist (Use During Any Review)

For each requirement, check:
- [ ] **Complete** -- All necessary information is present
- [ ] **Correct** -- Accurately reflects the stakeholder need
- [ ] **Feasible** -- Can be implemented within constraints
- [ ] **Necessary** -- Traces to a business objective (not gold-plating)
- [ ] **Prioritized** -- Has an assigned priority
- [ ] **Unambiguous** -- Only one possible interpretation
- [ ] **Verifiable** -- A test can prove it is satisfied
- [ ] **Consistent** -- Does not conflict with other requirements
- [ ] **Modifiable** -- Can be changed without ripple effects
- [ ] **Traceable** -- Unique ID, linked to source and test

---

## Examples

See `examples/sample.md` for a review planning example.

## Common Pitfalls

### Pitfall 1: Reviews That Are Really Presentations
**Symptom:** The author presents requirements while reviewers listen passively. Few defects are found.

**Consequence:** The review is an approval ceremony, not a quality gate.

**Fix:** Require independent preparation before the meeting. Most defects should be found during preparation, not during the meeting.

---

### Pitfall 2: Reviewing Too Much at Once
**Symptom:** Trying to inspect a 200-page SRS in one 2-hour meeting.

**Consequence:** Inspector fatigue. Defect detection drops dramatically after the first hour.

**Fix:** Review in chunks of 10-20 pages. Multiple shorter sessions are more effective than one marathon session.

---

### Pitfall 3: No Defect Checklist
**Symptom:** Reviewers read requirements and say "looks good" because they have no framework for what to look for.

**Consequence:** Systematic defect types (ambiguity, incompleteness) are consistently missed.

**Fix:** Provide the defect checklist. Train reviewers on what each defect type looks like with examples.

## References

### Related Skills
- `the requirements-validation-process skill (separate)` -- Full validation workflow that includes review as one component
- `../acceptance-criteria/SKILL.md` -- Acceptance criteria quality is verified during review
- `the srs-document skill (separate)` -- The SRS is the most common artifact reviewed

### External Frameworks
- Michael Fagan, "Design and Code Inspections" (1976) -- Original inspection process
- Tom Gilb & Dorothy Graham, *Software Inspection* (1993) -- Comprehensive inspection guide
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 17: Validating the Requirements
- Karl Wiegers, *Peer Reviews in Software* (2002) -- Review techniques and metrics

---

**Skill type:** Interactive
**Dependencies:** None
**Used by:** `the requirements-validation-process skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
