---
name: requirements-phase
description: "Run the Requirements phase: discovery, capture, stories, review, approval, baseline."
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [requirements, phase-1, user-stories, moscow, acceptance-criteria, nfr, gate-1, baseline]
    category: requirements-engineering
    related_skills: [requirements-elicitation-workshop, elicitation-interview, stakeholder-analysis, elicitation-technique-selector, writing-requirements, user-story-re, acceptance-criteria, quality-attribute, moscow-prioritization, vision-and-scope, requirements-review-advisor, specification-review-checklist, requirements-baselining, requirements-traceability]
---

# Requirements Phase Skill

Run Phase 1 (Requirements) of the project lifecycle end to end: from an approved one-pager to an **approved requirements baseline** (Gate 1). The agent runs a structured discovery session with the human, captures requirements into durable artifacts, writes user stories with acceptance criteria, applies MoSCoW, and submits the package to an **independent review** before the human's final approval. This phase decides *what* to build — never *how*: no framework/library choices, database schema, API design, folder structure, infrastructure, or implementation tasks here (governance Rule 7).

## When to Use

- Phase 0 produced an approved one-pager (`docs/idea.md` / `ONE-PAGER.md`) and the go/no-go was "go".
- A feature request arrives that is not fully specified ("vague intent", "we need an app that…", "a button that…").
- Requirements exist only in chat or "in everyone's head" — nothing written down.
- Scope is drifting and a definition of done is missing ("what does done look like?").

Do not use for: implementation planning, architecture, UX, or task decomposition — those are Phases 2–4.

## Prerequisites

- Approved Phase-0 one-pager, plus any prior context (`session_search`).
- The human (product owner) is available to answer a discovery session — no requirements loop with a phantom user.
- Target artifact locations: `docs/requirements.md` (confirmed requirements + approved baseline) and `docs/requirements/discovery.md` (assumptions, decisions, open questions). Create the repo's `docs/` tree if absent.

## How to Run

This is a session workflow, not a script. Work through the Procedure in order; each step ends with a checkable completion criterion. Use the companion skills for the technique deep-dives — the relevant one is named at each step.

## Procedure

### 1. Product intent
Take the one-pager as the initial input. List what is stated and what is missing; the goal is *discovery*, not re-negotiation. Completion: a short list of gaps to explore.

### 2. Discovery session (with the human)
Facilitate a structured conversation, not a questionnaire dump. Cover: actors/users and their goals, workflows, business rules, constraints, edge cases, expected outcomes, and success metrics. Ask context-free → context-specific → solution-oriented question levels.
- Never accept "we need a button that does X" — trace back to the underlying problem.
- Probe: scope (what is explicitly NOT included), success (how is it measured), failure (what does failure look like, who notices), dependencies, constraints (time, budget, compliance).
- Missing or ambiguous information is **explicitly identified** — never silently invented (Rule 7).
- Techniques: `requirements-elicitation-workshop` (session planning/agendas), `elicitation-interview` (interview question progression), `stakeholder-analysis` (who to involve), `elicitation-technique-selector` (which technique fits).
- Completion: every target area from step 1 is either answered or recorded as an open question.

### 3. Capture requirements (artifacts are the source of truth)
Persist the session output as structured artifacts separating the four categories: **confirmed requirements**, **assumptions**, **decisions**, **open questions**. The conversation is not the source of truth — the artifacts are. Write `docs/requirements/discovery.md` first, then derive `docs/requirements.md`.
- Quality bar for each requirement: `writing-requirements` (EARS templates, "shall/should/will", ambiguity watchlist).
- Note each assumption with an owner and expiry date; each open question with an owner.
- Completion: both files exist, and every discovery-session finding is in exactly one category.

### 4. User stories + acceptance criteria
Convert confirmed requirements into user stories: `As a [specific role], I want to [action], so that [measurable outcome]`. Keep stories appropriately scoped and independently understandable.
- `user-story-re` (INVEST gate, story decomposition, anti-patterns).
- Every story gets ≥3 testable acceptance criteria in Given / When / Then form (`acceptance-criteria`).
- Where workflows matter, capture them via basic flows in the story body or `use-case` modeling (if installed).
- Completion: every confirmed requirement maps to ≥1 story; every **Must** story has acceptance criteria.

### 5. MoSCoW prioritization + MVP
Apply Must / Should / Could / Won't and lock the MVP as the Must set (`moscow-prioritization`: litmus tests, 60/20/20 allocation sanity check). The MVP is final only after human confirmation.
- Completion: a prioritized backlog with an explicit MVP (Must) set exists in `docs/requirements.md`.

### 6. Non-functional requirements (NFRs)
Write down performance, security, availability, and budget NFRs — **including accessibility & localization**, folded in here and verified in QA (Phase 6). `quality-attribute` (taxonomy, Planguage notation, measurable thresholds — adjectives are not requirements).
- Completion: each NFR has a numeric threshold + measurement method, or an explicit decision not to set one.

### 7. Independent review (separate responsibility)
The complete package — stories, acceptance criteria, assumptions, decisions, open questions, captured requirements — is challenged by an **independent reviewer**. The same agent must NOT review its own work (separation of responsibilities). Run the review as a separate pass (different session/subagent profile when possible) that challenges, not approves:
- `requirements-review-advisor` (review formality selection, defect taxonomy: ambiguity, incompleteness, inconsistency, infeasibility, unverifiability, duplication, gold-plating, design-in-requirements).
- `specification-review-checklist` (individual-requirement and story-level defect checks).
- Check specifically for: hidden assumptions, incorrect scope, oversized stories, non-testable acceptance criteria, missing edge cases, duplicated/overlapping stories, inconsistencies between captured requirements and stories, and implementation details wrongly stated as requirements.
- Findings feed a **revision loop** with the author until the package is clean; **record findings and revisions** so the human can inspect what changed.
- Completion: zero open review findings; review artifact written (e.g., `docs/requirements/story-review.md`).

### 8. Human review and approval (Gate 1)
Present the final pre-approval packet: requirements, stories, assumptions, decisions, open questions, and the recorded review findings. The human is the final authority; no architecture or implementation planning proceeds until approval. If the human requests changes, revise the artifacts and repeat steps 7–8. On approval, mark the **requirements baseline** as approved (label + lock; `requirements-baselining`).

### 9. Baseline handoff
The approved baseline is what later phases consume: Architect scope (Phase 3), Milestone Planner backlog (Phase 4), SDD feature specs (Rule 6). Keep requirement IDs stable; maintain traceability from stories back to objectives (`requirements-traceability`).

## Pitfalls

- **Silent invention**: filling ambiguity with guesses instead of open questions — the #1 violation of Rule 7.
- **Self-review**: validating your own package without an independent Review pass — separation is mandatory.
- **Implementation leakage**: "use PostgreSQL", "call the X API", "route to /settings" — implementation details are Phase-3 decisions.
- **Vague NFRs**: "fast", "user-friendly", "secure" without thresholds — adjectives are not requirements.
- **Epics in disguise**: stories covering 5+ capabilities land back in review.
- **Chat as source of truth**: anything not in the artifacts does not exist.
- **Scoping after approval**: scope changes re-enter the human approval gate — never mutate the baseline quietly.

## Verification

Before declaring the phase complete, confirm every item:

- [ ] `docs/requirements.md` exists with confirmed requirements + prioritized backlog (MoSCoW) + MVP set
- [ ] `docs/requirements/discovery.md` exists with assumptions, decisions, open questions — each categorized
- [ ] Every **Must** story has ≥3 testable Given/When/Then acceptance criteria
- [ ] NFRs written down, including accessibility & localization; thresholds numeric
- [ ] Independent review performed (not by the author) with findings recorded, revision loop closed
- [ ] No open questions blocking scope (blockers surfaced to the human)
- [ ] Human approved the requirements baseline; baseline marked and versioned
- [ ] No implementation decisions (framework, schema, API, folder structure, infrastructure) appear in the artifacts
- [ ] Budget approved (Budget gate) — estimate and ceiling recorded

**Exit criterion (Gate 1):** *Requirements baseline approved + Scope locked + Budget approved.*