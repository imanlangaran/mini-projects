---
name: elicitation-technique-selector
description: Choose the right requirements elicitation technique based on project context, stakeholder access, and information needs. Use when deciding between interviews, workshops, observations, surveys, and other elicitation methods.
intent: >-
  Guide requirements engineers in selecting the most effective elicitation technique(s) for their specific situation by asking adaptive questions about stakeholder access, type of information needed, project constraints, and organizational culture. Use this to avoid defaulting to interviews for every situation when workshops, observation, document analysis, or prototyping might be more effective. Outputs a recommended technique combination with practical guidance tailored to your context.
type: interactive
theme: re-process
best_for:
  - "Choosing elicitation techniques for a new project or phase"
  - "Deciding between interviews, workshops, and observation"
  - "Adapting elicitation approach to stakeholder constraints"
scenarios:
  - "I have limited access to users (only 3 hours total) and need to maximize what I learn"
  - "Help me decide whether to run a workshop or do individual interviews for this project"
  - "Users can't articulate what they need -- what elicitation technique should I use?"
estimated_time: "10-15 min"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['elicitation', 'technique', 'selection']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Guide requirements engineers in selecting the most effective elicitation technique(s) for their situation. Use this to move beyond "interview everyone" and choose techniques that match your stakeholder access, information needs, and project constraints.

This is not a technique manual -- it is a decision guide. For detailed technique instructions, see `../requirements-elicitation-workshop/SKILL.md`.

## Key Concepts

### The Elicitation Technique Toolbox

| Technique | Best For | Requires | Yields |
|-----------|---------|----------|--------|
| **Interviews** | Deep individual knowledge, sensitive topics | 30-60 min per stakeholder | Detailed qualitative data |
| **Workshops** | Group consensus, cross-functional alignment | Multiple stakeholders simultaneously | Shared understanding, prioritized requirements |
| **Observation** | Actual workflows, undocumented processes | Physical access to work environment | Tacit knowledge, real process data |
| **Questionnaires** | Large user populations, quantitative data | Well-designed questions, distribution channel | Broad coverage, statistical patterns |
| **Document Analysis** | Existing systems, regulations, policies | Access to documentation | Business rules, constraints, data formats |
| **Interface Analysis** | System integrations, data exchanges | Access to connected systems | Interface requirements, data formats |
| **Prototyping** | UI-intensive systems, unclear requirements | Prototyping tools, user access for feedback | Validated UI requirements, usability feedback |
| **Focus Groups** | Market-facing products, user preferences | 6-10 representative users | User preferences, feature priorities |

### Technique Selection Factors

1. **Stakeholder access** -- How much time do you have with real users?
2. **Type of information** -- Explicit knowledge (policies) vs. tacit knowledge (workflows)?
3. **Number of stakeholders** -- Few key individuals or large user populations?
4. **Project phase** -- Early discovery vs. requirements elaboration vs. validation?
5. **Domain complexity** -- Well-understood domain vs. novel territory?
6. **Organizational culture** -- Collaborative vs. hierarchical? Open vs. guarded?

### The Right Combination
No single technique is sufficient. Effective elicitation uses 2-4 complementary techniques:
- Interviews + Document Analysis (most common starting combination)
- Workshops + Prototyping (for collaborative, UI-intensive projects)
- Observation + Interviews (when users cannot articulate their needs)

## Application

### Interactive Selection Process

**Question 1: What type of information do you need most?**

1. **Business processes and workflows** -- How people currently do their work
2. **Business rules and policies** -- Organizational rules that govern behavior
3. **User interface needs** -- What users need to see and interact with
4. **Data and integration requirements** -- What data flows where
5. **Quality expectations** -- Performance, security, reliability targets
6. **A mix of the above** -- Broad discovery across multiple areas

---

**Question 2: How much access do you have to real users/stakeholders?**

1. **Extensive** -- Regular access, users are willing and available (weekly or more)
2. **Moderate** -- Some access, but constrained (a few sessions over several weeks)
3. **Limited** -- Very restricted access (a few hours total with users)
4. **None** -- No direct user access (must work through proxies or documentation)

---

**Question 3: What is the organizational culture like?**

1. **Collaborative** -- People enjoy group activities, open to sharing
2. **Hierarchical** -- People defer to authority, careful about speaking up in groups
3. **Distributed** -- Team spread across locations/time zones
4. **Mixed/Unknown** -- Unsure or varies by group

---

**Question 4: What project phase are you in?**

1. **Early discovery** -- Understanding the problem space, identifying needs
2. **Requirements elaboration** -- Detailing known requirements
3. **Requirements validation** -- Confirming requirements with stakeholders
4. **Enhancement/replacement** -- Existing system being modified or replaced

---

### Recommendation Logic

Based on your answers, here are the recommended technique combinations:

**If business processes + extensive access + collaborative:**
- Primary: **Facilitated Workshop** (group process mapping, consensus building)
- Secondary: **Observation** (validate workshop outputs against real workflows)
- Supplement: **Document Analysis** (existing procedures, forms, reports)

**If business processes + limited access:**
- Primary: **Observation** (maximize the limited time by watching real work)
- Secondary: **Structured Interviews** (follow up on what you observed)
- Supplement: **Document Analysis** (compensate for limited access)

**If business rules + any access level:**
- Primary: **Document Analysis** (policy manuals, regulations, existing systems)
- Secondary: **Interviews** with domain experts (clarify ambiguous rules)
- Supplement: **Decision Table construction** (validate rule combinations)

**If UI needs + moderate or extensive access:**
- Primary: **Prototyping** (paper or electronic prototypes for feedback)
- Secondary: **Focus Groups** (user preference validation)
- Supplement: **Observation** (current workflow to ground the design)

**If data/integration + any access level:**
- Primary: **Interface Analysis** (examine existing systems and data flows)
- Secondary: **Document Analysis** (API specs, data dictionaries, schemas)
- Supplement: **Interviews** with technical stakeholders

**If quality expectations:**
- Primary: **Interviews** with key stakeholders (elicit expectations)
- Secondary: **Questionnaire** (broader survey for priority ranking)
- Supplement: Use `../quality-attribute/SKILL.md` process

**If early discovery + extensive access + collaborative:**
- Primary: **Workshop** (vision, scope, stakeholder alignment)
- Secondary: **Interviews** (deep dives with key stakeholders)
- Tertiary: **Observation** (understand current state)

**If no user access:**
- Primary: **Document Analysis** (every document you can find)
- Secondary: **Interface Analysis** (reverse-engineer from existing systems)
- Tertiary: **Questionnaire** (sent via email to users you cannot meet)
- Warning: High risk of missing tacit knowledge. Escalate access limitations.

---

## Examples

See `examples/sample.md` for a sample technique selection walkthrough.

## Common Pitfalls

### Pitfall 1: Interviews for Everything
**Symptom:** Every elicitation session is a one-on-one interview, regardless of context.

**Consequence:** Missed group dynamics, no consensus building, slower convergence.

**Fix:** Use workshops when you need group alignment. Use observation when users cannot articulate their needs. Match technique to information type.

---

### Pitfall 2: Skipping Observation
**Symptom:** Requirements based entirely on what users *say* they do, never what they *actually* do.

**Consequence:** Requirements miss workarounds, undocumented steps, and tacit knowledge.

**Fix:** Include at least one observation session. Even 2 hours of watching real work reveals insights that 10 hours of interviews miss.

---

### Pitfall 3: Questionnaires for Complex Topics
**Symptom:** Sending a survey asking "What features do you need?" to 500 users.

**Consequence:** Low response rates, superficial answers, analysis paralysis.

**Fix:** Use questionnaires for specific, closed-ended questions (priority rankings, frequency data). Use interviews or workshops for open-ended exploration.

---

### Pitfall 4: Single Technique
**Symptom:** Using only one elicitation technique for the entire project.

**Consequence:** Systematic blind spots. No single technique captures all requirement types.

**Fix:** Always combine at least 2-3 techniques. Each compensates for the others' weaknesses.

## References

### Related Skills
- `../requirements-elicitation-workshop/SKILL.md` -- Detailed workshop facilitation process
- `../stakeholder-analysis/SKILL.md` -- Identifies who to involve in elicitation
- `../vision-and-scope/SKILL.md` -- Often the first artifact produced from elicitation

### External Frameworks
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 7: Hearing the Voice of the Customer
- IIBA, *BABOK Guide* (2015) -- Elicitation and Collaboration knowledge area
- Ellen Gottesdiener, *Requirements by Collaboration* (2002) -- Workshop facilitation

---

**Skill type:** Interactive
**Dependencies:** References `../stakeholder-analysis/SKILL.md`
**Used by:** `../requirements-elicitation-workshop/SKILL.md`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
