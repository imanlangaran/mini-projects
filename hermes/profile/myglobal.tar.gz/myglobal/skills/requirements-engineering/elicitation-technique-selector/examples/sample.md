# Elicitation Technique Selector Example

## Example: ChemTrack Project Elicitation Planning

```markdown
## Situation
Starting requirements elicitation for ChemTrack chemical inventory
management system at a university.

## Answers to Selection Questions

**Q1: Type of information needed?**
A mix -- business processes (how labs manage chemicals today), business
rules (regulatory compliance), UI needs (daily technician interface),
and data requirements (chemical record structure).

**Q2: Stakeholder access?**
Moderate -- Lab technicians are busy (limited to 2-3 sessions of 1 hour
each). EHS officers are available weekly. Lab directors available monthly.

**Q3: Organizational culture?**
Hierarchical -- Faculty (lab directors) are not accustomed to being
"interviewed" by IT staff. Technicians are practical and collaborative
but deferential to directors.

**Q4: Project phase?**
Early discovery -- understanding the problem space, identifying requirements
for a system that does not yet exist.

## Recommended Technique Combination

### Primary: Observation (2 sessions, 2 hours each)
**Why:** Lab technicians have limited time and difficulty articulating
implicit workflows. Watching them manage chemicals will reveal undocumented
steps, workarounds, and pain points that interviews would miss.

**Plan:**
- Session 1: Observe chemical intake and inventory entry process
- Session 2: Observe chemical retrieval for experiments and disposal

### Secondary: Structured Interviews (4 sessions, 1 hour each)
**Why:** Follow up on observations with targeted questions. Different
interview approach for different stakeholder types.

**Plan:**
- 2 sessions with lab technicians (process details, pain points)
- 1 session with EHS officer (regulatory rules, compliance reporting)
- 1 session with lab director (approval workflows, reporting needs)

### Tertiary: Document Analysis (ongoing)
**Why:** Regulatory documents and existing forms contain business rules
that stakeholders take for granted and might not mention. Compensates
for limited user access.

**Plan:**
- Review EPA reporting forms and requirements
- Analyze existing spreadsheet templates used for tracking
- Review university EHS policy manual
- Examine any existing chemical management procedures

### Supplement: Paper Prototyping (2 sessions, 1 hour each)
**Why:** UI needs are important, and technicians are better at reacting
to concrete designs than describing abstract needs.

**Plan:**
- After initial requirements are drafted, create paper mockups
- Walk through with 2 technicians: "Would this screen support your
  daily workflow?"

### Explicitly Excluded
- **Workshop:** Not recommended due to hierarchical culture. Technicians
  may not speak freely in front of directors. Use individual sessions
  instead.
- **Questionnaire:** User population is small (12 lab technicians).
  Individual interviews are more effective at this scale.
- **Focus Group:** Not a market-facing product; no need for preference
  data from a representative user panel.
```

**Why this works:**
- Multiple techniques complement each other (observation catches what interviews miss)
- Limited user access is addressed with observation (high-value per hour)
- Hierarchical culture is respected (individual sessions, not workshops)
- Document analysis compensates for access limitations
- Each technique has a specific plan with session count and focus areas
- Excluded techniques have explicit rationale
