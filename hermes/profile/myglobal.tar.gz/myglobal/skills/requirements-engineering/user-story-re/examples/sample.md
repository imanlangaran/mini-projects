# User Story Examples (RE Context)

## Example 1: Good User Story

```markdown
### US-015: Chemical Expiration Alert

**As a** lab technician,
**I want to** receive an email alert 30 days before a chemical in my
assigned storage area expires,
**So that** I can arrange disposal or replacement before the chemical
becomes a safety hazard or violates regulatory compliance.

#### Acceptance Criteria:
- [ ] Email sent exactly 30 days before the expiration date
- [ ] Email includes: chemical name, CAS number, quantity, storage
      location, and expiration date
- [ ] Email sent to the technician assigned to the chemical's storage location
- [ ] If no technician is assigned, email sent to the lab manager
- [ ] No alert sent for chemicals with status "Disposed" or "Transferred"
- [ ] Alert is logged in the system audit trail with timestamp and recipient

#### Requirements Attributes:
- **Priority:** High
- **Source:** Lab Technician user class (Maria Santos, product champion)
- **Business Rules:** BR-011 (Expiration notification timeline)
- **Traces to:** BO-2 (Eliminate expired chemicals), FE-2 (Expiration alerts)
- **Status:** Approved

#### INVEST Check:
- [x] Independent -- No dependency on other stories
- [x] Negotiable -- Could be email, in-app, or SMS (to be discussed)
- [x] Valuable -- Prevents safety hazards and compliance violations
- [x] Estimable -- Team estimates 5 story points
- [x] Small -- Single sprint delivery
- [x] Testable -- All acceptance criteria are verifiable
```

**Why this works:**
- Specific user class ("lab technician"), not generic "user"
- Clear capability with a specific trigger (30 days before expiration)
- Genuine business value (safety + compliance, not just "so I know")
- 6 acceptance criteria, all testable
- Full traceability to business objectives and features
- INVEST criteria all pass

---

## Example 2: Weak User Story (Before Improvement)

```markdown
### US-099: Search

**As a** user,
**I want to** search for things,
**So that** I can find what I need.

#### Acceptance Criteria:
- [ ] Search works
```

**Problems:**
- "User" is too generic -- which user class?
- "Search for things" -- what things? By what criteria?
- "Find what I need" restates the action
- One acceptance criterion that is not testable ("works")
- No traceability, no priority, no source

**After improvement:**

```markdown
### US-023: Chemical Search by CAS Number

**As a** lab technician,
**I want to** search for chemicals by CAS number and see matching results
with location and expiration information,
**So that** I can quickly locate a specific chemical for an experiment
without walking through the entire lab.

#### Acceptance Criteria:
- [ ] Search accepts full or partial CAS number input
- [ ] Results display within 2 seconds for up to 50,000 records
- [ ] Each result shows: chemical name, CAS number, quantity, location,
      expiration date
- [ ] Results sorted by location (nearest first) when user's lab is known
- [ ] "No results found" message displayed for unmatched searches
- [ ] Search is accessible from every screen via a persistent search bar

#### Requirements Attributes:
- **Priority:** High
- **Source:** Lab Technician user class (Maria Santos)
- **Business Rules:** None
- **Traces to:** BO-1 (Reduce reporting time), FE-1 (Chemical catalog)
- **Status:** Approved
```
