---
name: user-story-re
description: Write requirements-focused user stories with INVEST criteria and structured acceptance criteria. Use when capturing user needs in agile RE contexts where traceability and testability matter.
intent: >-
  Create user stories that satisfy requirements engineering standards -- not just agile placeholders for conversation, but traceable, testable, prioritized expressions of user need. Each story follows the "As a / I want / So that" format with structured acceptance criteria, and is evaluated against the INVEST criteria (Independent, Negotiable, Valuable, Estimable, Small, Testable). Use this when working in agile or hybrid environments where user stories serve as the primary requirements artifact.
type: component
theme: re-artifacts
best_for:
  - "Writing user stories that meet RE quality standards"
  - "Adding acceptance criteria that are testable and traceable"
  - "Evaluating stories against INVEST criteria before sprint planning"
scenarios:
  - "I need user stories for an agile project that also need to satisfy regulatory traceability"
  - "My team writes vague user stories. I need a quality standard."
estimated_time: "5-15 min per story"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['user-stories', 'agile', 'invest']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Create user stories that satisfy requirements engineering standards -- traceable, testable, prioritized expressions of user need. Each story follows the "As a / I want / So that" format with structured acceptance criteria, evaluated against the INVEST criteria. Use this in agile or hybrid environments where user stories serve as requirements artifacts.

This is not about replacing formal requirements with sticky notes. It is about writing user stories with enough rigor to serve as traceable, verifiable requirements while keeping the conversational, user-centered spirit of agile.

## Key Concepts

### User Story Format
```
As a [user class or persona],
I want to [action or capability],
So that [business value or outcome].
```

Every word earns its place:
- **As a** -- Forces identification of a specific user class (not "as a user")
- **I want to** -- Describes the capability from the user's perspective
- **So that** -- Explains the business value (not a restatement of the action)

### INVEST Criteria
Use this as a quality gate before accepting a story into a sprint:

| Criterion | Question | Red Flag |
|-----------|----------|----------|
| **Independent** | Can this story be developed and delivered without depending on another story? | "We can't do this until Story X is done" |
| **Negotiable** | Is there room for discussion on implementation? | Overly prescriptive implementation details |
| **Valuable** | Does it deliver value to a user or customer? | "As a developer, I want to refactor..." |
| **Estimable** | Can the team estimate the effort? | "We have no idea how complex this is" |
| **Small** | Can it be completed in one sprint? | Epic disguised as a story |
| **Testable** | Can you write a test to verify it? | "The system should be user-friendly" |

### Acceptance Criteria Formats

**Given/When/Then (Gherkin):**
```
Given [precondition],
When [action],
Then [expected result].
```

**Checklist format:**
```
- [ ] [Verifiable condition 1]
- [ ] [Verifiable condition 2]
- [ ] [Verifiable condition 3]
```

**Rule-based:**
```
Rule: [Business rule that must be satisfied]
Example: [Concrete example of the rule in action]
```

### User Stories in the Requirements Hierarchy
```
Business Requirements (Vision and Scope)
  -> Epics (large user needs)
    -> User Stories (sprint-sized capabilities)
      -> Acceptance Criteria (testable conditions)
        -> Tasks (implementation work)
```

### Anti-Patterns
- **Technical Stories** -- "As a developer, I want to upgrade the database" (not user value)
- **Epic in Disguise** -- One story covering 5+ capabilities
- **Vague Value** -- "So that I can use the system" (restating the obvious)
- **No Acceptance Criteria** -- Story with no way to verify completion

## Application

Use `template.md` for the fill-in structure.

### Step 1: Identify the User Class
Reference your stakeholder analysis (`../stakeholder-analysis/SKILL.md`). Use the specific user class name, not "user."

Good: "As a lab technician"
Bad: "As a user"

### Step 2: Write the Story Statement
Focus on the *what* (capability) and *why* (value), not the *how* (implementation).

Good: "I want to receive an alert when a chemical is about to expire, so that I can remove or replace it before it becomes a safety hazard."
Bad: "I want the system to send an email with the subject ALERT and a red icon, so that I see the alert."

### Step 3: Write Acceptance Criteria

For each story, write 3-7 acceptance criteria. Each criterion must be:
- **Specific** -- Concrete condition, not vague
- **Testable** -- A tester can verify pass/fail
- **Independent** -- Each criterion stands alone

```markdown
#### Acceptance Criteria:
- [ ] Alert is sent via email 30 days before chemical expiration
- [ ] Alert includes chemical name, CAS number, location, and expiration date
- [ ] Alert is sent to the lab technician assigned to the chemical's storage location
- [ ] If the technician has no email on file, alert is sent to the lab manager
- [ ] Alert is not sent for chemicals already marked as "Disposed"
```

### Step 4: Add Requirements Attributes

For RE contexts, augment each story with:
- **Story ID** -- Unique persistent identifier (US-001, US-002)
- **Priority** -- High / Medium / Low (or MoSCoW)
- **Source** -- Who requested this (stakeholder, user class, regulation)
- **Business Rule** -- BR-IDs that govern this story
- **Traces to** -- Business objective or feature in vision and scope
- **Status** -- Proposed / Approved / Implemented / Verified

### Step 5: Validate Against INVEST

Before accepting the story, check each INVEST criterion. If any fails, revise:

- Not Independent? Identify the dependency and either remove it or sequence the stories.
- Not Valuable? Rewrite to express user value, or reclassify as a technical task.
- Not Small? Split using techniques: workflow steps, business rules, data variations, CRUD operations, or happy/sad paths.
- Not Testable? Add specific, measurable acceptance criteria.

---

## Examples

See `examples/sample.md` for complete examples.

Mini example:

```markdown
### US-015: Expiration Alert for Lab Technician
**As a** lab technician,
**I want to** receive an email alert 30 days before a chemical expires,
**So that** I can arrange disposal or replacement before it becomes a
safety hazard.

**Acceptance Criteria:**
- [ ] Email sent 30 days before expiration date
- [ ] Email includes: chemical name, CAS number, location, expiration date
- [ ] Email sent to technician assigned to the storage location
- [ ] No alert for chemicals already marked "Disposed"
- [ ] Alert logged in system audit trail

**Priority:** High
**Source:** Lab Technician user class (Maria Santos)
**Business Rules:** BR-011
**Traces to:** BO-2 (Eliminate expired chemicals)
```

## Common Pitfalls

### Pitfall 1: Stories Without Acceptance Criteria
**Symptom:** "As a user, I want to search for chemicals." No criteria for what constitutes a successful search.

**Consequence:** Developer implements minimal search. Tester has no basis for testing. Arguments ensue.

**Fix:** Every story must have at least 3 acceptance criteria before entering a sprint.

---

### Pitfall 2: "So That" Restates "I Want To"
**Symptom:** "I want to log in, so that I can access the system."

**Consequence:** No insight into why this matters. Does not help prioritize.

**Fix:** Dig into the real value: "so that I can check my experiment results without walking to the lab."

---

### Pitfall 3: Too Big (Epic in Disguise)
**Symptom:** A single story with 15 acceptance criteria covering multiple capabilities.

**Consequence:** Cannot be completed in one sprint. Too complex to estimate.

**Fix:** Split by workflow step, business rule, data variation, or happy/sad path. Each resulting story should have 3-7 acceptance criteria.

---

### Pitfall 4: No Traceability
**Symptom:** 200 user stories in a backlog with no link to business objectives.

**Consequence:** Cannot answer "why are we building this?" Cannot demonstrate coverage of business needs.

**Fix:** Add a "Traces to" attribute linking each story to a business objective or feature in the vision and scope document.

## References

### Related Skills
- `../stakeholder-analysis/SKILL.md` -- User classes for the "As a" clause
- `../acceptance-criteria/SKILL.md` -- Detailed guidance on writing acceptance criteria
- `the use-case skill (separate)` -- More detailed alternative for complex interactions
- `../vision-and-scope/SKILL.md` -- Business objectives that stories trace to
- `../requirements-traceability/SKILL.md` -- Maintaining story-to-objective traceability

### External Frameworks
- Mike Cohn, *User Stories Applied* (2004) -- Origin of the format
- Bill Wake, "INVEST in Good Stories" (2003) -- The INVEST acronym
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 8

---

**Skill type:** Component
**Dependencies:** References `../stakeholder-analysis/SKILL.md`, `../vision-and-scope/SKILL.md`
**Used by:** `the requirements-analysis-process skill (separate)`, `the srs-document skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
