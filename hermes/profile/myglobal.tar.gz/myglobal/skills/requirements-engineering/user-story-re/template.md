# User Story Template (RE Context)

Use this template to write a user story with acceptance criteria and requirements attributes.

## Template

```markdown
### [Story ID]: [Brief Title]

**As a** [user class or persona],
**I want to** [action or capability],
**So that** [business value or outcome].

#### Acceptance Criteria:
- [ ] [Testable condition 1]
- [ ] [Testable condition 2]
- [ ] [Testable condition 3]

#### Requirements Attributes:
- **Priority:** [High / Medium / Low]
- **Source:** [Who requested or needs this]
- **Business Rules:** [BR-IDs]
- **Traces to:** [Business objective or feature ID]
- **Status:** [Proposed / Approved / Implemented / Verified]
- **Sprint:** [Target sprint, if assigned]

#### INVEST Check:
- [ ] Independent -- Can be delivered without other stories
- [ ] Negotiable -- Implementation is open to discussion
- [ ] Valuable -- Delivers value to a user or customer
- [ ] Estimable -- Team can estimate the effort
- [ ] Small -- Fits in one sprint
- [ ] Testable -- Acceptance criteria can be verified
```

## Notes
- Use specific user class names, not generic "user."
- The "So that" clause must state genuine value, not restate the action.
- 3-7 acceptance criteria per story is the target range.
- If a story fails the INVEST check, revise before sprint planning.
