---
name: requirements-elicitation-workshop
description: Plan and execute a structured requirements elicitation session using multiple techniques. Use when you need to systematically gather requirements from stakeholders through a planned combination of interviews, workshops, observation, and document analysis.
intent: >-
  Guide requirements engineers through planning and executing a complete elicitation session -- from preparation through facilitation to post-session synthesis. Orchestrates elicitation techniques (interviews, workshops, observation, document analysis) into a structured session plan with specific agendas, participant roles, and expected outputs. Use this when ad-hoc elicitation is producing incomplete or inconsistent results and you need a repeatable, thorough process.
type: workflow
theme: re-process
best_for:
  - "Planning a structured elicitation session for a new project"
  - "Running an effective requirements workshop with multiple stakeholders"
  - "Synthesizing elicitation outputs into actionable requirements"
scenarios:
  - "I have a 3-hour window with 5 stakeholders. Help me plan the session."
  - "We keep getting incomplete requirements from interviews. I need a better process."
estimated_time: "30-45 min planning; 2-4 hours execution per session"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['elicitation', 'workshop', 'discovery', 'facilitation']
    category: requirements-engineering
    related_skills: ['elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Guide requirements engineers through planning and executing structured elicitation sessions. Orchestrate multiple techniques into a session plan with specific agendas, participant roles, and expected outputs.

This is not a single-technique instruction. It is the workflow that sequences techniques, manages participants, and synthesizes outputs into requirements.

## Key Concepts

### Elicitation Session Types

| Type | Participants | Duration | Best For |
|------|-------------|----------|---------|
| **Discovery Workshop** | 5-10 stakeholders | 2-4 hours | Initial requirements for a new project |
| **Deep-Dive Interview** | 1-2 domain experts | 1-2 hours | Detailed requirements for specific areas |
| **Observation Session** | 1 observer + users | 2-4 hours | Undocumented workflows, tacit knowledge |
| **Review & Validation** | 3-7 mixed stakeholders | 1-2 hours | Confirming drafted requirements |

### Elicitation Preparation Checklist
Before any elicitation session:
- [ ] Objective defined (what you need to learn)
- [ ] Participants identified and confirmed (from `../stakeholder-analysis/SKILL.md`)
- [ ] Technique selected (from `../elicitation-technique-selector/SKILL.md`)
- [ ] Materials prepared (agenda, current artifacts, questions)
- [ ] Logistics arranged (room, tools, recording permission)
- [ ] Prior knowledge reviewed (existing docs, previous session notes)

### The Elicitation Workflow
```
Prepare -> Conduct -> Document -> Synthesize -> Validate
```

## Application

### Phase 1: Prepare (1-2 hours before session)

**1.1 Define the Objective**
Write a single sentence: "By the end of this session, we will have [specific output]."

Examples:
- "...identified all user classes and their primary goals"
- "...documented the current chemical tracking workflow with pain points"
- "...specified acceptance criteria for the top 5 user stories"

**1.2 Select Participants**
From your stakeholder analysis:
- Include at least one representative from each affected user class
- Include a domain expert if business rules are involved
- Limit workshops to 5-10 people (more reduces productivity)
- Always include a product champion

**1.3 Prepare the Agenda**

For a **Discovery Workshop** (3 hours):
```
00:00 - 00:15  Welcome, objectives, ground rules
00:15 - 00:45  Context setting (current state, problems, goals)
00:45 - 01:30  Elicitation Activity 1 (e.g., process walkthrough)
01:30 - 01:45  Break
01:45 - 02:30  Elicitation Activity 2 (e.g., requirement brainstorming)
02:30 - 02:50  Prioritization (quick MoSCoW or dot voting)
02:50 - 03:00  Wrap-up, next steps, action items
```

For a **Deep-Dive Interview** (1 hour):
```
00:00 - 00:05  Objective and rapport building
00:05 - 00:15  Context questions (role, workflow, tools)
00:15 - 00:40  Core questions (specific topic deep dive)
00:40 - 00:50  Scenarios and edge cases
00:50 - 00:55  "What else should I know?" (open-ended)
00:55 - 01:00  Next steps and thank you
```

**1.4 Prepare Questions**

Three types of questions, in order:
1. **Context-free questions** -- About the problem, not the solution
   - "What problem are you trying to solve?"
   - "Who is affected by this problem?"
   - "What does a successful outcome look like?"

2. **Context-specific questions** -- About the current situation
   - "Walk me through how you do X today."
   - "What are the most time-consuming parts of this process?"
   - "What happens when Y goes wrong?"

3. **Solution-oriented questions** -- About desired future state
   - "If you could change one thing about this process, what would it be?"
   - "What would make you confident the new system works?"
   - "Are there constraints we must respect?"

---

### Phase 2: Conduct the Session

**2.1 Facilitation Rules**
- Listen more than you talk (80/20 rule)
- Ask "why?" and "what happens when...?" to dig deeper
- Never argue with a stakeholder's answer (capture it, validate later)
- Document everything -- even things that seem unimportant
- Watch for body language (confusion, disagreement, excitement)
- Manage dominant participants (redirect: "That's helpful. Let's hear from others.")

**2.2 Capture Techniques**
- Whiteboard / digital whiteboard for visual models
- Sticky notes for brainstorming (one idea per note)
- Notebook for detailed notes (quotations are gold)
- Audio recording (if permitted) for later review
- Assign a dedicated note-taker separate from the facilitator

**2.3 Elicitation Activities**

**Process Walkthrough (30-45 min):**
1. Ask the user to walk through their workflow step by step
2. For each step, ask: Who? What? When? Where? Why? How?
3. Identify pain points, workarounds, and decision points
4. Draw the process as you go (swimlane or flowchart)

**Requirement Brainstorming (30-45 min):**
1. Pose the question: "What does the system need to do for you?"
2. Capture all ideas without judgment (5-10 minutes of free flow)
3. Group similar ideas
4. Discuss and clarify each group
5. Identify gaps: "What about X? What about error handling?"

**Scenario Walking (20-30 min):**
1. Present a realistic scenario: "Imagine you receive a shipment of chemicals..."
2. Ask: "What do you do first? Then what? What if X goes wrong?"
3. This surfaces requirements that abstract questions miss

---

### Phase 3: Document (30-60 min after session)

Within 24 hours of the session:

1. **Consolidate raw notes** into structured format
2. **Draft initial requirements** (user stories, shall statements, or use cases)
3. **Flag open questions** -- Things you need to follow up on
4. **Identify conflicts** -- Where stakeholders disagreed
5. **List assumptions** -- Things assumed but not confirmed

---

### Phase 4: Synthesize (1-2 hours)

1. **Map elicitation outputs to requirements format:**
   - Process walkthroughs -> Use cases or activity diagrams
   - Brainstormed needs -> User stories
   - Business rules mentioned -> Business rule catalog entries
   - Data mentioned -> Data dictionary entries
   - Quality concerns -> Quality attribute specifications

2. **Cross-reference with existing artifacts:**
   - Do new requirements align with the vision and scope?
   - Are there gaps in coverage vs. business objectives?
   - Are there conflicts with previously documented requirements?

3. **Prepare the output package:**
   - Draft requirements (using appropriate skill templates)
   - Open questions list
   - Conflict resolution items
   - Follow-up session plan (if needed)

---

### Phase 5: Validate (next session or async)

1. Send draft requirements to session participants for review
2. Ask: "Does this accurately capture what you told us?"
3. Resolve conflicts between stakeholder perspectives
4. Schedule follow-up sessions for open questions

---

## Examples

See `examples/sample.md` for a complete session plan and output.

## Common Pitfalls

### Pitfall 1: No Preparation
**Symptom:** Facilitator shows up to the session without a plan, agenda, or prepared questions.

**Consequence:** Session meanders. Participants lose confidence. Important topics are missed.

**Fix:** Invest 1-2 hours in preparation for every elicitation session. The agenda, questions, and participant list should be ready before the session starts.

---

### Pitfall 2: Leading Questions
**Symptom:** "Don't you think we should use a dropdown for this field?" (leading toward a specific solution)

**Consequence:** You get confirmation of your assumptions instead of discovering actual needs.

**Fix:** Ask open-ended questions: "How do you expect to select a value here?" Let the stakeholder define the need; you design the solution later.

---

### Pitfall 3: No Follow-Up Documentation
**Symptom:** Great session, lots of insights, but nobody writes anything down afterward.

**Consequence:** Insights are lost. Two weeks later, nobody remembers the details.

**Fix:** Document within 24 hours. Send draft requirements to participants within 48 hours for confirmation.

---

### Pitfall 4: Stakeholder Domination
**Symptom:** One person talks for 80% of the session. Others are silent.

**Consequence:** Requirements reflect one perspective, not the group's. Quiet stakeholders' needs are missed.

**Fix:** Use round-robin techniques: "Let's go around the room. Each person shares one need." Address dominant speakers directly: "Thank you, that's very helpful. I'd like to hear from others as well."

## References

### Related Skills
- `../elicitation-technique-selector/SKILL.md` -- Choose techniques before the workshop
- `../stakeholder-analysis/SKILL.md` -- Identify participants
- `../vision-and-scope/SKILL.md` -- Output: vision and scope document
- `the use-case skill (separate)` -- Output: use case specifications
- `../user-story-re/SKILL.md` -- Output: user stories
- `the business-rule skill (separate)` -- Output: business rule catalog

### External Frameworks
- Ellen Gottesdiener, *Requirements by Collaboration* (2002) -- Workshop techniques
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 7
- Suzanne Robertson & James Robertson, *Mastering the Requirements Process* (2012)

---

**Skill type:** Workflow
**Dependencies:** Orchestrates `../elicitation-technique-selector/SKILL.md`, `../stakeholder-analysis/SKILL.md`
**Outputs:** `the use-case skill (separate)`, `../user-story-re/SKILL.md`, `the business-rule skill (separate)`, `../vision-and-scope/SKILL.md`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
