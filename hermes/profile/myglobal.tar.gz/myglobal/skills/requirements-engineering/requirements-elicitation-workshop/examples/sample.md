# Elicitation Workshop Example

## Example: ChemTrack Discovery Workshop Plan

```markdown
# Elicitation Session Plan: ChemTrack Initial Discovery

**Date:** 2025-03-25
**Facilitator:** Sarah Chen, BA
**Note-taker:** James Wong, Junior BA
**Duration:** 3 hours (09:00 - 12:00)
**Location:** Chemistry Building, Conference Room 204

---

## Objective
By the end of this session, we will have identified all primary user
workflows for chemical inventory management, key pain points with
the current spreadsheet-based process, and initial requirements for
the top 3 features.

## Participants

| Name | Role | Perspective |
|------|------|-------------|
| Maria Santos | Lab Technician | Daily chemical management |
| Dr. James Lee | Lab Director | Oversight and approvals |
| Tom Rivera | EHS Officer | Regulatory compliance |
| Kim Park | Lab Technician | Chemistry Dept workflow |
| Sarah Chen | BA / Facilitator | Requirements capture |
| James Wong | Junior BA / Note-taker | Documentation |

## Preparation Done
- [x] Reviewed existing chemical tracking spreadsheets (3 templates)
- [x] Read EPA regulatory reporting requirements (40 CFR 260-270)
- [x] Interviewed Tom Rivera informally (30 min phone call)
- [x] Prepared agenda and question list
- [x] Printed current workflow diagrams for annotation
- [x] Arranged sticky notes, markers, whiteboard

---

## Agenda

### 09:00-09:15 Welcome and Ground Rules (15 min)
- Introductions and roles
- Ground rules: No bad ideas, one speaker at a time, phones off
- Objective statement on the whiteboard
- Permission to record (audio) -- consent forms signed

### 09:15-09:45 Context Setting (30 min)
**Activity:** Current State Walkthrough
- Maria walks through a typical day of chemical management
- Tom describes the quarterly compliance reporting process
- Dr. Lee describes the approval and oversight process
- Capture on whiteboard: swimlane diagram

**Key questions:**
- "Walk me through receiving a new chemical shipment."
- "How do you currently track which chemicals are about to expire?"
- "What happens when you need to find a specific chemical in the lab?"
- "Walk me through generating the quarterly EPA report."

### 09:45-10:30 Pain Point Elicitation (45 min)
**Activity:** Sticky Note Brainstorm + Affinity Grouping
1. Each participant writes pain points on sticky notes (5 min, silent)
2. Post on whiteboard and read aloud (10 min)
3. Group similar pain points into themes (10 min)
4. Discuss each theme: severity, frequency, impact (20 min)

**Probing questions for each theme:**
- "How often does this happen?"
- "What is the consequence when it does?"
- "How do you work around it today?"

### 10:30-10:45 Break (15 min)

### 10:45-11:30 Requirement Brainstorming (45 min)
**Activity:** "What Would Make Your Life Easier?"
1. For each pain point theme, brainstorm solutions (sticky notes, 10 min)
2. Group into feature areas (10 min)
3. Discuss feasibility and priority (25 min)
   - Dot voting: each participant gets 5 dots to place on priorities

**Questions:**
- "If you could change one thing, what would it be?"
- "What does the system need to do that the spreadsheets can't?"
- "What would make you confident the chemical data is accurate?"

### 11:30-11:50 Prioritization (20 min)
**Activity:** Quick MoSCoW
- Group voted features into Must/Should/Could/Won't for Release 1
- Capture rationale for Must-Have items

### 11:50-12:00 Wrap-Up (10 min)
- Review action items
- Confirm follow-up sessions (individual interviews with Maria, Tom)
- Thank participants
- Timeline: draft requirements sent for review within 1 week

---

## Post-Session Output (Completed within 24 hours)

### Pain Points Identified (Grouped by Theme)

**Theme 1: Expired Chemicals (12 sticky notes)**
- Chemicals expire without anyone noticing
- Quarterly audit finds 10-15% of inventory expired
- Near-miss safety incident with expired reagent in Feb 2025
- No automated alerts or reminders

**Theme 2: Reporting Burden (8 sticky notes)**
- EPA report takes 2-3 days of manual data compilation
- Data scattered across 6 different spreadsheets
- Format changes each year require re-doing the template
- No way to quickly verify data accuracy

**Theme 3: Search and Location (6 sticky notes)**
- Finding a specific chemical requires walking through the lab
- No central lookup by CAS number
- Chemicals sometimes moved without updating spreadsheet
- New staff don't know the "system" (informal knowledge)

### Draft Requirements (Initial)
[Captured as user stories using skills/user-story-re template]
- 8 Must-Have stories identified
- 5 Should-Have stories
- 4 Could-Have stories
- 3 deferred to future release

### Follow-Up Actions
1. Individual interview with Maria (chemical intake workflow detail)
2. Individual interview with Tom (compliance reporting requirements)
3. Observe Kim doing actual chemical inventory update (2 hours)
4. Document analysis: review EPA form 8700-12 and state equivalents
```

**Why this works:**
- Clear objective, participants, and agenda before the session
- Multiple techniques in one session (walkthrough, brainstorm, prioritization)
- Facilitation notes include probing questions (not just "discuss")
- Post-session documentation is structured and actionable
- Follow-up actions ensure elicitation continues beyond the workshop
