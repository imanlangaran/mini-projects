# Vision and Scope Document Template

Use this template to create a vision and scope document for a new project or product.

## Provenance
Adapted from the vision and scope document template in *Software Requirements, Third Edition* by Karl Wiegers and Joy Beatty (Chapter 5).

## Template

```markdown
# Vision and Scope Document: [Project Name]

**Version:** [x.y]
**Date:** [YYYY-MM-DD]
**Author:** [Name]
**Status:** [Draft | Under Review | Approved | Baselined]

---

## 1. Business Requirements

### 1.1 Background
[1-2 paragraphs describing the business problem or opportunity that drives this project.]

### 1.2 Business Objectives
[List 3-7 measurable objectives.]

- **BO-1:** [Objective statement with quantified target]
- **BO-2:** [Objective statement with quantified target]
- **BO-3:** [Objective statement with quantified target]

### 1.3 Success Metrics

| Metric | Baseline | Target | Measurement Method | Timeframe |
|--------|----------|--------|--------------------|-----------|
| [Name] | [Current] | [Goal] | [How measured] | [When] |

### 1.4 Vision Statement
For [target customer] who [need or opportunity], the [product name] is a [product category] that [key benefit]. Unlike [current alternative], our product [primary differentiator].

### 1.5 Business Risks

| Risk ID | Description | Likelihood | Impact | Mitigation |
|---------|-------------|------------|--------|------------|
| BR-1 | [Risk description] | H/M/L | H/M/L | [How to mitigate] |

### 1.6 Business Assumptions and Dependencies
- [Assumption 1]
- [Assumption 2]
- [Dependency 1]

---

## 2. Scope and Limitations

### 2.1 Major Features

| Feature ID | Feature Name | Description | Priority | Supports |
|-----------|--------------|-------------|----------|----------|
| FE-1 | [Name] | [Description] | H/M/L | BO-1 |
| FE-2 | [Name] | [Description] | H/M/L | BO-2 |

### 2.2 Scope of Initial Release
[Describe what the first release will include.]

### 2.3 Scope of Subsequent Releases
[Describe planned future releases and what is deferred.]

### 2.4 Limitations and Exclusions
[Explicitly list what is out of scope and why.]

- **OUT-1:** [Item] -- [Rationale]
- **OUT-2:** [Item] -- [Rationale]

---

## 3. Business Context

### 3.1 Stakeholder Profiles

| Stakeholder | Major Value | Attitude | Key Interests | Constraints |
|-------------|-------------|----------|---------------|-------------|
| [Role/Name] | [What they get] | Champion/Supporter/Neutral/Critic | [Interests] | [Limitations] |

### 3.2 Project Priorities

| Dimension | Constraint | Driver | Degree of Freedom |
|-----------|------------|--------|-------------------|
| Schedule  |            |        |                   |
| Features  |            |        |                   |
| Quality   |            |        |                   |
| Staff     |            |        |                   |
| Cost      |            |        |                   |

### 3.3 Deployment Considerations
- **Target environment:** [Cloud / On-prem / Hybrid]
- **Rollout strategy:** [Big bang / Phased / Pilot]
- **Migration needs:** [Data migration, integration cutover, etc.]
```

## Notes
- Each column in the Priority Matrix should have exactly one checkmark.
- Every feature in section 2.1 should trace to at least one business objective in section 1.2.
- The out-of-scope list (2.4) is as important as the in-scope list. Do not skip it.
