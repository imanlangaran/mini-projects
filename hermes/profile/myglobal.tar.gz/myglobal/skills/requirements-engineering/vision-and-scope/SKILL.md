---
name: vision-and-scope
description: Create a vision and scope document that captures business requirements, project scope, and stakeholder context. Use when launching a new project or product to align all parties on objectives and boundaries.
intent: >-
  Guide requirements engineers through building a vision and scope document that defines business requirements (objectives, success metrics, risk), project scope (features, limitations, exclusions), and business context (stakeholder profiles, priorities, deployment). Use this to prevent scope creep, align stakeholders on what the project will and will not deliver, and provide a stable foundation for all downstream requirements work.
type: component
theme: re-artifacts
best_for:
  - "Defining project objectives and measurable success criteria"
  - "Establishing scope boundaries before elicitation begins"
  - "Aligning stakeholders on what is in and out of scope"
scenarios:
  - "I'm starting a new project and need to document the business requirements and scope before elicitation"
  - "Stakeholders disagree on what the product should do -- I need a vision and scope document to align them"
estimated_time: "60-90 min"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['vision', 'scope', 'business-requirements']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Guide requirements engineers through building a vision and scope document that defines business requirements (objectives, success metrics, risk), project scope (features, limitations, exclusions), and business context (stakeholder profiles, priorities, deployment). Use this to prevent scope creep, align stakeholders on what the project will and will not deliver, and provide a stable foundation for all downstream requirements work.

This is not a full SRS -- it is the strategic framing document that precedes detailed requirements. Think of it as the contract between the business sponsor and the project team on *why* the project exists and *what it covers*.

## Key Concepts

### Three Layers of Business Requirements
Business requirements sit at the top of the requirements hierarchy:

1. **Business Requirements** -- Why the project exists (objectives, success metrics)
2. **User Requirements** -- What users need to accomplish (use cases, user stories)
3. **Functional Requirements** -- What the system must do (detailed behaviors)

The vision and scope document captures layer 1 and bounds layer 2 and 3.

### Business Objectives Model
Structure objectives as a hierarchy:

- **Problem or Opportunity** -- The business driver (e.g., "Customer onboarding takes 3 weeks, causing 30% drop-off")
- **Business Objectives** -- Measurable goals (e.g., "Reduce onboarding time to 3 days")
- **Success Metrics** -- How you measure achievement (e.g., "Onboarding completion rate rises from 70% to 95%")
- **Vision Statement** -- One sentence capturing the product direction

### Scope Representation Techniques
Multiple tools to bound scope:

- **Context Diagram** -- Shows the system as a single bubble with all external entities and data flows (see `the context-diagram skill (separate)`)
- **Feature Tree** -- Hierarchical decomposition of features into sub-features
- **Event List** -- Catalog of business, signal, and temporal events the system responds to
- **In/Out Table** -- Explicit two-column list of what is in scope and what is not

### Anti-Patterns (What This Is NOT)
- **Not a PRD** -- The vision and scope document is shorter, focused on *why* and *boundaries*, not detailed solutions
- **Not a wish list** -- Every feature in scope must trace to a business objective
- **Not immutable** -- Update it when project direction changes, but treat changes as controlled decisions

## Application

Use `template.md` for the full fill-in structure.

### Step 1: Define Business Requirements

**1.1 Background**
Write 1-2 paragraphs on why this project exists. Describe the problem or opportunity driving the initiative.

**1.2 Business Objectives**
List 3-7 measurable objectives. Each objective should have:
- A clear statement of what will change
- A quantified target (increase X by Y%, reduce Z from A to B)
- A measurement method

**Example:**
```
BO-1: Reduce average customer onboarding time from 21 days to 3 days,
      measured by median time-to-first-value in analytics dashboard.
BO-2: Increase trial-to-paid conversion rate from 12% to 25%,
      measured by monthly cohort analysis.
```

**1.3 Success Metrics**
For each business objective, define:
- **Metric name** -- What you measure
- **Current baseline** -- Where you are today
- **Target** -- Where you need to be
- **Measurement method** -- How you will measure it
- **Timeframe** -- When you expect to reach the target

**1.4 Vision Statement**
Write one sentence: "For [target customer] who [need], the [product] is a [category] that [key benefit]. Unlike [alternative], our product [differentiator]."

**1.5 Business Risks**
List the top 3-5 risks to the project. For each:
- **Risk description** -- What could go wrong
- **Likelihood** -- High / Medium / Low
- **Impact** -- High / Medium / Low
- **Mitigation** -- What you will do about it

---

### Step 2: Define Scope and Limitations

**2.1 Major Features**
List each feature that is in scope. For each feature:
- **Feature ID** (e.g., FE-1, FE-2)
- **Feature name**
- **Description** -- 1-2 sentences
- **Priority** -- High / Medium / Low
- **Business objective(s) it supports** -- Trace back to BO-x

**2.2 Scope Limitations**
Explicitly list what is *out of scope* and why:
```
OUT-1: Mobile app (Phase 2, desktop-first for initial launch)
OUT-2: Multi-language support (not needed for initial English-only market)
OUT-3: Integration with legacy ERP (will be addressed in separate project)
```

**2.3 Scope Visualization**
Create one or more:
- Context diagram showing system boundary and external actors
- Feature tree showing in-scope features organized hierarchically
- In/Out table for quick stakeholder reference

---

### Step 3: Document Business Context

**3.1 Stakeholder Profiles**
For each stakeholder group:
- **Name/Role** -- Who they are
- **Major value** -- What they get from the product
- **Attitude** -- Champion / Supporter / Neutral / Critic
- **Major interests** -- What they care about most
- **Constraints** -- Limitations they impose

**3.2 Project Priorities**
Use a priority matrix to lock trade-off decisions:

| Dimension    | Constraint | Driver | Degree of Freedom |
|-------------|------------|--------|-------------------|
| Schedule    |            |        |                   |
| Features    |            |        |                   |
| Quality     |            |        |                   |
| Staff       |            |        |                   |
| Cost        |            |        |                   |

Rules: Each column gets exactly one checkmark per row. Each row gets exactly one checkmark. This forces explicit trade-off decisions.

**3.3 Deployment Considerations**
- Target environment (cloud, on-prem, hybrid)
- Rollout strategy (big bang, phased, pilot)
- Migration needs (data, integrations)

---

### Step 4: Review and Validate

- Walk through the document with the project sponsor
- Verify every feature traces to at least one business objective
- Confirm the out-of-scope list with stakeholders who might assume those items are included
- Obtain formal sign-off or baseline the document

---

## Examples

See `examples/sample.md` for a complete vision and scope document.

Mini example excerpt:

```markdown
## Business Requirements

### Background
ChemTrack is a desktop application for managing chemical inventory in
university labs. Lab managers currently track chemicals via spreadsheets,
resulting in expired chemicals going unnoticed and regulatory reporting
taking 2-3 days per quarter.

### Business Objectives
- BO-1: Reduce time to generate quarterly regulatory report from 3 days
  to 4 hours
- BO-2: Eliminate expired chemicals remaining in inventory (currently 12%
  of stock at any time)
- BO-3: Achieve 90% adoption among target lab managers within 6 months

### Vision Statement
For university lab managers who struggle with manual chemical tracking,
ChemTrack is an inventory management system that automates compliance
reporting and expiration alerts. Unlike spreadsheet tracking, ChemTrack
provides real-time visibility and regulatory-ready reports.
```

## Common Pitfalls

### Pitfall 1: Objectives Without Metrics
**Symptom:** "Improve user experience" or "Increase efficiency" with no numbers attached.

**Consequence:** No way to measure success. The project can never be declared done or evaluated.

**Fix:** Every objective needs a quantified target and a measurement method. If you cannot measure it, refine the objective until you can.

---

### Pitfall 2: Scope by Omission
**Symptom:** The document lists what is in scope but never states what is out.

**Consequence:** Stakeholders assume their favorite feature is included. Scope creep follows.

**Fix:** Explicitly list out-of-scope items with rationale. This is uncomfortable but prevents far worse conflict later.

---

### Pitfall 3: Too Many Business Objectives
**Symptom:** 15-20 objectives that cover everything imaginable.

**Consequence:** No focus. Everything is a priority, so nothing is.

**Fix:** Limit to 3-7 objectives. If you have more, the project is too broad -- split it.

---

### Pitfall 4: Vision Statement as Marketing Copy
**Symptom:** The vision statement reads like a press release with buzzwords.

**Consequence:** Does not guide decisions. Team cannot use it to resolve scope disputes.

**Fix:** Use the structured format: For [who] who [need], the [product] is a [category] that [benefit]. Unlike [alternative], our product [differentiator].

---

### Pitfall 5: No Stakeholder Priority Matrix
**Symptom:** Schedule, features, quality, staff, and cost are all "top priority."

**Consequence:** When trade-offs arise (they always do), there is no framework for deciding.

**Fix:** Force-rank using the constraint/driver/degree-of-freedom matrix. Every dimension gets exactly one designation.

## References

### Related Skills
- `the context-diagram skill (separate)` -- System boundary definition using context diagrams
- `../stakeholder-analysis/SKILL.md` -- Detailed stakeholder identification and analysis
- `the srs-document skill (separate)` -- The downstream detailed specification that this document feeds
- `../quality-attribute/SKILL.md` -- Non-functional requirements that may affect scope

### External Frameworks
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 5: Establishing the Business Requirements
- Geoffrey Moore, *Crossing the Chasm* (1991) -- Vision statement template
- Suzanne Robertson & James Robertson, *Mastering the Requirements Process* (2012) -- Scope modeling

### Provenance
- Adapted from the vision and scope document template in *Software Requirements, Third Edition*, Chapter 5.

---

**Skill type:** Component
**Suggested filename:** `vision-and-scope`
**Dependencies:** References `the context-diagram skill (separate)`, `../stakeholder-analysis/SKILL.md`
**Used by:** `the srs-document skill (separate)`, `../requirements-elicitation-workshop/SKILL.md`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
