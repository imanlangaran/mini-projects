# Vision and Scope Document Example

## Example 1: Good Vision and Scope Document

```markdown
# Vision and Scope Document: ChemTrack

**Version:** 1.0
**Date:** 2025-03-15
**Author:** Sarah Chen, Senior BA
**Status:** Approved

---

## 1. Business Requirements

### 1.1 Background
University research labs currently manage chemical inventories using
spreadsheets maintained by individual lab managers. This approach results
in expired chemicals sitting on shelves unnoticed (averaging 12% of
inventory at any given time), regulatory compliance reports taking 2-3
full work days per quarter, and no visibility into chemical usage across
departments. Two recent near-miss safety incidents were traced to
unlabeled or expired chemicals. The university's Environmental Health and
Safety office has mandated improvement by end of fiscal year.

### 1.2 Business Objectives
- **BO-1:** Reduce quarterly regulatory report generation from 3 days to
  4 hours, measured by time tracked per EHS staff member
- **BO-2:** Eliminate expired chemicals remaining in active inventory
  (currently 12% of stock), measured by quarterly audit
- **BO-3:** Achieve 90% adoption among chemistry and biology department
  lab managers within 6 months of launch
- **BO-4:** Reduce safety incidents related to chemical mismanagement from
  4 per year to 0, measured by incident reports

### 1.3 Success Metrics

| Metric | Baseline | Target | Method | Timeframe |
|--------|----------|--------|--------|-----------|
| Report generation time | 3 days | 4 hours | Time tracking | 6 months |
| Expired chemical rate | 12% | 0% | Quarterly audit | 12 months |
| Lab manager adoption | 0% | 90% | Login analytics | 6 months |
| Safety incidents | 4/year | 0/year | Incident reports | 12 months |

### 1.4 Vision Statement
For university lab managers who struggle with manual chemical tracking,
ChemTrack is an inventory management system that automates compliance
reporting and expiration alerts. Unlike spreadsheet tracking, ChemTrack
provides real-time visibility and regulatory-ready reports.

### 1.5 Business Risks

| Risk ID | Description | Likelihood | Impact | Mitigation |
|---------|-------------|------------|--------|------------|
| BR-1 | Lab managers resist adopting new system | High | High | Early user involvement, phased rollout, department champions |
| BR-2 | Initial data entry of existing inventory too burdensome | Medium | Medium | Provide student assistants for initial data load |
| BR-3 | Regulatory format changes mid-project | Low | Medium | Modular report templates, monitor EPA/state changes |

---

## 2. Scope and Limitations

### 2.1 Major Features

| Feature ID | Name | Description | Priority | Supports |
|-----------|------|-------------|----------|----------|
| FE-1 | Chemical catalog | Search, add, edit chemical records with SDS links | High | BO-1, BO-2 |
| FE-2 | Expiration alerts | Automated email 30/7/1 days before chemical expires | High | BO-2, BO-4 |
| FE-3 | Regulatory reports | One-click generation of EPA and state compliance reports | High | BO-1 |
| FE-4 | Barcode scanning | Scan chemical containers to look up or add inventory | Medium | BO-3 |
| FE-5 | Usage logging | Track chemical consumption per lab/researcher | Medium | BO-1, BO-4 |
| FE-6 | Dashboard | Visual overview of inventory status, alerts, compliance | Low | BO-3 |

### 2.2 Scope of Initial Release
Release 1.0 covers FE-1, FE-2, FE-3 (core inventory, alerts, and
reporting). This delivers the minimum needed to satisfy the EHS mandate.

### 2.3 Scope of Subsequent Releases
- Release 2.0: FE-4, FE-5 (barcode scanning, usage logging)
- Release 3.0: FE-6 (dashboard), cross-department analytics

### 2.4 Limitations and Exclusions
- **OUT-1:** Mobile app -- Desktop-only for initial release; most lab
  managers work from lab desktops
- **OUT-2:** Procurement integration -- Will not auto-order chemicals;
  manual reorder process stays
- **OUT-3:** Multi-university support -- Single university deployment only
- **OUT-4:** Biological materials tracking -- Separate regulatory domain

---

## 3. Business Context

### 3.1 Stakeholder Profiles

| Stakeholder | Major Value | Attitude | Key Interests | Constraints |
|-------------|-----------|----------|---------------|-------------|
| Lab Managers | Less time on compliance | Neutral (cautious) | Easy to use, minimal data entry | Limited computer time |
| EHS Office | Real-time compliance data | Champion | Audit readiness, accurate data | Regulatory deadlines |
| Dept Chairs | Budget justification | Supporter | Cost control, safety record | Limited IT budget |
| IT Dept | Maintainability | Neutral | Standard tech stack, security | Staff availability |

### 3.2 Project Priorities

| Dimension | Constraint | Driver | Degree of Freedom |
|-----------|------------|--------|-------------------|
| Schedule  | X          |        |                   |
| Features  |            |        | X                 |
| Quality   |            | X      |                   |
| Staff     |            |        | X                 |
| Cost      | X          |        |                   |
```

**Why this works:**
- Objectives are specific and measurable (numbers, timeframes)
- Each feature traces to business objectives
- Out-of-scope items are explicit with rationale
- Stakeholder attitudes are honestly assessed (not everyone is a champion)
- Priority matrix forces real trade-off decisions (quality is the driver, so features can flex)

---

## Example 2: Weak Vision and Scope (Anti-Pattern)

```markdown
## Vision
Build a world-class chemical management platform that leverages
cutting-edge technology to revolutionize laboratory operations.

## Objectives
- Improve efficiency
- Better compliance
- User-friendly system
- Modern architecture

## Scope
Everything related to chemical management in the university.
```

**Why this fails:**
- Vision is marketing copy, not a decision-making guide
- Objectives have no measurements or targets
- "Everything related to" is not a scope boundary -- it is an invitation to scope creep
- No stakeholders, no priorities, no risks, no out-of-scope items
