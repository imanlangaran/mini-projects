---
name: requirements-baselining
description: Establish and manage requirements baselines with version control, entry criteria, and approval processes. Use when requirements reach a stable state and need a formal reference point for change control.
intent: >-
  Guide requirements engineers through establishing formal requirements baselines with proper version labeling, entry criteria, configuration management, and approval processes. Use this when requirements have been reviewed and approved to a level of stability that justifies a formal snapshot -- the reference point against which all future changes are measured. Without baselining, there is no "before" for change control, no version for traceability, and no agreement on what was actually committed.
type: component
theme: re-artifacts
best_for:
  - "Establishing a formal reference point after requirements approval"
  - "Setting up version control and labeling conventions for requirements documents"
  - "Defining entry criteria that requirements must meet before baselining"
scenarios:
  - "The SRS has been reviewed and approved -- I need to formally baseline it before development begins"
  - "We are starting Release 2 and need to know exactly what was in the Release 1 baseline"
  - "An auditor asks which version of the requirements was used for the current build"
estimated_time: "30-45 min"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['baseline', 'approval', 'versioning', 'gate']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-traceability']
---


## Purpose
Guide requirements engineers through establishing formal requirements baselines -- agreed-upon, versioned snapshots of requirements at a point in time. A baseline is the reference point against which all future changes are measured, all traceability links are anchored, and all development commitments are based.

Without a baseline, there is no way to answer: "What exactly did we agree to build?" Changes cannot be assessed because there is no "before" to compare against. Traceability links point to moving targets. Auditors have nothing to audit.

## Key Concepts

### What Constitutes a Baseline

A requirements baseline is:
- A **snapshot** of all requirements (and their attributes) at a specific point in time
- **Approved** by authorized stakeholders
- **Immutable** -- once baselined, the content does not change. Changes create a new version.
- **Labeled** with a unique version identifier
- **Stored** under configuration management

A baseline is not the same as "the latest version." It is a specific, frozen version that was formally reviewed and approved.

### Version Labeling Conventions

Wiegers recommends a structured labeling scheme:

| Label Format | Meaning | Example |
|-------------|---------|---------|
| Version X.Y draft Z | Draft in progress, not yet approved | Version 1.0 draft 3 |
| Version X.Y approved | Formally reviewed and approved | Version 1.0 approved |
| Version X.Y | Shorthand for the approved version | Version 1.0 |

Version numbering rules:
- **Major version (X)** -- Incremented for significant scope changes (new release, major rework)
- **Minor version (Y)** -- Incremented for approved changes within a release
- **Draft (Z)** -- Incremented for working drafts not yet approved

Example progression for ChemTrack SRS:
```
Version 1.0 draft 1  -- Initial draft after elicitation
Version 1.0 draft 2  -- Updated after first review
Version 1.0 draft 3  -- Updated after second review
Version 1.0 approved  -- Baselined for Release 1 development
Version 1.1 draft 1  -- Incorporates CR-003 and CR-005
Version 1.1 approved  -- Updated baseline after change approval
Version 2.0 draft 1  -- Release 2 scope expansion begins
```

### Entry Criteria for Baselining

A requirements document should not be baselined until it meets minimum quality criteria:

- [ ] All requirements have been formally reviewed (see `../specification-review-checklist/SKILL.md`)
- [ ] All review action items have been resolved
- [ ] All TBD items have been resolved or explicitly deferred with rationale
- [ ] Requirements are uniquely identified with stable IDs
- [ ] Priority has been assigned to all requirements
- [ ] All requirements are testable
- [ ] Traceability links are established (requirements to business objectives, at minimum)
- [ ] All stakeholders with sign-off authority have approved
- [ ] No open high-severity defects from requirements inspection

### Configuration Management for Requirements

Configuration management (CM) ensures that:
- Every version of every requirements document is stored and retrievable
- Changes are tracked with author, date, and rationale
- The current baseline is always identifiable
- Previous baselines can be retrieved for comparison
- Concurrent changes are managed without loss

Tools for requirements CM:
- Version control systems (Git, SVN) for document-based requirements
- Requirements management tools (DOORS, Jama, Azure DevOps) for database-stored requirements
- Document management systems (SharePoint, Confluence) with version history

### Baseline Review and Approval Process

1. **Author** prepares the baseline candidate and verifies entry criteria
2. **Peer reviewers** verify content quality (via `../specification-review-checklist/SKILL.md`)
3. **Technical lead** verifies feasibility and consistency
4. **Product owner / business stakeholder** verifies completeness and correctness
5. **Project manager** authorizes the baseline
6. **Configuration manager** applies the version label and locks the baseline

### Why This Works
- **Creates accountability** -- Everyone agrees on what was committed
- **Enables change control** -- Changes are measured against a known reference point
- **Supports audits** -- Regulators and auditors can see exactly what was specified at any point
- **Prevents "requirements drift"** -- Without a baseline, requirements change invisibly and no one notices until the project is off track

### Anti-Patterns
- **Premature Baselining** -- Baselining before requirements are stable enough. This leads to immediate change requests that undermine the baseline.
- **Never Baselining** -- Requirements are always "in progress" and never formally frozen. No reference point exists for change control.
- **Baseline Without Approval** -- A version is labeled as "baselined" but was never formally reviewed or approved by stakeholders.

## Application

Use `template.md` for the full baseline record structure.

### Step 1: Verify Entry Criteria

Before proposing a baseline, walk through the entry criteria checklist. For ChemTrack Release 1:

```
Entry Criteria Assessment:
[x] Formal review completed (Review #3, 2025-03-20)
[x] All review action items resolved (12/12 closed)
[x] TBD items resolved (3 deferred to Release 2 with rationale)
[x] All requirements have unique IDs (FR-01 through FR-42, NFR-01 through NFR-15)
[x] Priority assigned (MoSCoW categorization completed)
[x] All requirements testable (verified during review)
[x] Traceability established (requirements -> business objectives)
[x] Stakeholder sign-off obtained (4/4 approvers signed)
[x] No open high-severity defects (0 open)

Result: READY FOR BASELINING
```

### Step 2: Prepare the Baseline Record

Create a baseline record document that captures:
- Baseline identifier and version label
- Date of baselining
- List of documents included in the baseline
- List of approvers and their sign-off dates
- Summary of what changed since the previous baseline (if applicable)
- Known issues or deferred items

### Step 3: Obtain Formal Approval

Route the baseline for approval. Minimum approvers:
- Product owner or business sponsor (content correctness)
- Technical lead (feasibility)
- Project manager (schedule and scope commitment)
- Quality assurance lead (testability)

For regulated environments, add:
- Compliance officer
- Safety officer (if applicable)

### Step 4: Apply Version Label and Lock

Once approved:
1. Apply the version label (e.g., "Version 1.0 approved")
2. Lock the document/repository to prevent uncontrolled changes
3. Store the baseline in the configuration management system
4. Distribute the baseline notification to all stakeholders

In Git-based CM:
```bash
git tag -a "SRS-v1.0-approved" -m "ChemTrack SRS Version 1.0 baseline"
git push origin "SRS-v1.0-approved"
```

In a requirements management tool, mark the baseline and lock the requirement set.

### Step 5: Communicate the Baseline

Notify all stakeholders:
- What was baselined (document name, version)
- Where to find it (repository URL, tool location)
- What it means (development can begin / changes require CR process)
- How to request changes (pointer to the change control process)

### Step 6: Manage Post-Baseline Changes

After baselining, all changes must go through the change control process (`the change-impact-analysis skill (separate)`):
1. Submit a change request
2. Perform impact analysis
3. CCB approves/defers/rejects
4. If approved, update requirements and create a new baseline version

---

## Examples

See `examples/sample.md` for a complete baseline record.

Mini example excerpt:

```markdown
## Baseline Record: ChemTrack SRS v1.0

**Baseline ID:** BL-CT-001
**Version:** 1.0 approved
**Date:** 2025-04-01
**Previous Baseline:** None (initial baseline)

### Documents Included
| Document | Version | Location |
|----------|---------|----------|
| SRS      | 1.0     | /docs/chemtrack-srs-v1.0.pdf |
| Vision & Scope | 1.0 | /docs/chemtrack-vs-v1.0.pdf |
| Glossary | 1.0     | /docs/chemtrack-glossary-v1.0.pdf |

### Approvals
| Role | Name | Date | Status |
|------|------|------|--------|
| Product Owner | Dr. James Lee | 2025-03-28 | Approved |
| Tech Lead | Sarah Chen | 2025-03-29 | Approved |
| PM | Mike Johnson | 2025-03-30 | Approved |
| QA Lead | Lisa Park | 2025-03-30 | Approved |
```

## Common Pitfalls

### Pitfall 1: Baselining Too Early
**Symptom:** A baseline is established while requirements are still volatile. Multiple change requests arrive within the first week.

**Consequence:** The baseline is immediately outdated. Change control overhead is wasted on changes that should have been caught in review.

**Fix:** Verify entry criteria rigorously. If more than 10% of requirements have open issues, the document is not ready for baselining.

---

### Pitfall 2: Baselining Too Late (or Never)
**Symptom:** Development begins before requirements are baselined. Requirements continue to evolve informally.

**Consequence:** No reference point for change control. Developers build against a moving target. "But I thought we agreed..." conversations proliferate.

**Fix:** Set a baselining milestone in the project plan. Development should not begin on a set of requirements until that set is baselined.

---

### Pitfall 3: Baseline Without Configuration Management
**Symptom:** The baseline is "the document on Sarah's laptop" or "the version we emailed last Friday."

**Consequence:** The baseline cannot be reliably retrieved. Multiple versions circulate. Nobody knows which is authoritative.

**Fix:** Store baselines in a version-controlled repository or requirements management tool. The baseline must be retrievable by any authorized stakeholder at any time.

---

### Pitfall 4: Informal Approval
**Symptom:** The baseline is "approved" based on verbal agreement in a meeting, with no documented sign-off.

**Consequence:** Six months later, a stakeholder claims they never approved a particular requirement. There is no evidence to the contrary.

**Fix:** Require documented sign-off (digital signature, email confirmation, or tool-based approval workflow). Record the approver, date, and any conditions.

---

### Pitfall 5: No Baseline Change History
**Symptom:** The baseline is updated but there is no record of what changed between versions.

**Consequence:** Cannot determine what changed between Version 1.0 and Version 1.1. Impact analysis for future changes lacks context.

**Fix:** Every new baseline version includes a change summary: which change requests were incorporated, which requirements were added/modified/deleted.

## References

### Related Skills
- `the change-impact-analysis skill (separate)` -- Post-baseline changes require impact analysis
- `../specification-review-checklist/SKILL.md` -- Reviews are a prerequisite for baselining
- `../requirements-traceability/SKILL.md` -- Traceability links are anchored to baselined requirements
- `the requirements-status-tracking skill (separate)` -- Status tracking references the current baseline
- `the srs-document skill (separate)` -- The SRS is the most commonly baselined requirements document

### External Frameworks
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 27: Requirements Configuration Management
- IEEE 828-2012, *Standard for Configuration Management in Systems and Software Engineering*
- CMMI for Development, Version 1.3 -- Configuration Management process area

---

**Skill type:** Component
**Dependencies:** References `the change-impact-analysis skill (separate)`, `../specification-review-checklist/SKILL.md`
**Used by:** `the change-impact-analysis skill (separate)`, `the requirements-status-tracking skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
