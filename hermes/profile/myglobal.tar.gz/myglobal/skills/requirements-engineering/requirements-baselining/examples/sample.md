# Requirements Baseline Record Example

## Example: ChemTrack Lab Inventory System -- Release 1 Baseline

```markdown
# Requirements Baseline Record

## Baseline Identification

| Attribute | Value |
|-----------|-------|
| **Baseline ID:** | BL-CT-001 |
| **Version Label:** | Version 1.0 approved |
| **Date Established:** | 2025-04-01 |
| **Previous Baseline:** | None (initial baseline) |
| **Project:** | ChemTrack Lab Inventory System |
| **Release:** | Release 1 |

## Documents Included

| Document | Version | Location |
|----------|---------|----------|
| Software Requirements Specification | 1.0 | /docs/chemtrack-srs-v1.0.pdf |
| Vision and Scope Document | 1.0 | /docs/chemtrack-vs-v1.0.pdf |
| Glossary | 1.0 | /docs/chemtrack-glossary-v1.0.pdf |
| Traceability Matrix | 1.0 | /docs/chemtrack-trace-v1.0.xlsx |

## Entry Criteria Verification

| Criterion | Status | Evidence |
|-----------|--------|----------|
| Formal review completed | Pass | Review RV-003, 2025-03-20 |
| Review action items resolved | Pass | 12 of 12 closed |
| TBD items resolved or deferred | Pass | 0 open; 3 deferred with rationale |
| Requirements uniquely identified | Pass | FR-01 to FR-42, NFR-01 to NFR-15 |
| Priority assigned | Pass | MoSCoW completed 2025-04-05 |
| All requirements testable | Pass | Verified during RV-003 |
| Traceability established | Pass | All trace to BO-1 through BO-5 |
| Stakeholder sign-off obtained | Pass | 4 of 4 signed |
| No open high-severity defects | Pass | 0 open |

**Result:** READY FOR BASELINING

## Baseline Contents Summary

| Category | Count | ID Range |
|----------|-------|----------|
| Functional requirements | 42 | FR-01 to FR-42 |
| Non-functional requirements | 15 | NFR-01 to NFR-15 |
| Business rules | 8 | BR-01 to BR-08 |
| Constraints | 5 | CON-01 to CON-05 |
| **Total** | **70** | |

## Approvals

| Role | Name | Date | Decision | Comments |
|------|------|------|----------|----------|
| Product Owner | Dr. James Lee | 2025-03-28 | Approved | Barcode scanning for Release 2 |
| Technical Lead | Sarah Chen | 2025-03-29 | Approved | NFR-03 targets aggressive but achievable |
| Project Manager | Mike Johnson | 2025-03-30 | Approved | Aligns with Release 1 schedule |
| QA Lead | Lisa Park | 2025-03-30 | Approved | All requirements have acceptance criteria |

## Known Issues and Deferred Items

| Item | Deferred To | Rationale |
|------|-------------|-----------|
| Barcode scanner hardware model | Release 2 | Vendor evaluation pending |
| Mobile device support | Release 2 | Awaiting adoption data |
| Procurement API specification | Release 2/3 | External dependency |

## Version History

| Version | Date | Description |
|---------|------|-------------|
| 1.0 draft 1 | 2025-02-15 | Initial draft after elicitation |
| 1.0 draft 2 | 2025-03-05 | Updated after informal review |
| 1.0 draft 3 | 2025-03-18 | Updated after peer review |
| 1.0 approved | 2025-04-01 | Baselined after formal review and sign-off |
```

**Why this works:**
- Entry criteria verified with specific evidence (review IDs, counts, dates)
- All documents enumerated with version and location
- Approvals recorded with dates, names, and conditional comments
- Deferred items tracked with rationale and target release
- Version history shows progression from draft to approved baseline
