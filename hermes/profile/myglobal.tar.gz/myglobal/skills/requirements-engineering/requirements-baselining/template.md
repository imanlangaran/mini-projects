# Requirements Baseline Record Template

Use this template to document a formal requirements baseline with version control and approval records.

## Template

```markdown
# Requirements Baseline Record

## Baseline Identification

| Attribute | Value |
|-----------|-------|
| **Baseline ID:** | [BL-XXX-NNN] |
| **Version Label:** | [Version X.Y approved] |
| **Date Established:** | [YYYY-MM-DD] |
| **Previous Baseline:** | [ID or "None (initial)"] |
| **Project:** | [Project name] |
| **Release:** | [Release identifier] |

## Documents Included

| Document | Version | Location |
|----------|---------|----------|
| [Document name] | [X.Y] | [Path or URL] |

## Entry Criteria Verification

| Criterion | Status | Evidence |
|-----------|--------|----------|
| Formal review completed | [Pass/Fail] | [Review ID] |
| Review action items resolved | [Pass/Fail] | [X of Y closed] |
| TBD items resolved or deferred | [Pass/Fail] | [Count] |
| Requirements uniquely identified | [Pass/Fail] | [ID range] |
| Priority assigned | [Pass/Fail] | [Method] |
| All requirements testable | [Pass/Fail] | [Method] |
| Traceability established | [Pass/Fail] | [Location] |
| Stakeholder sign-off obtained | [Pass/Fail] | [Count] |
| No open high-severity defects | [Pass/Fail] | [Count] |

**Result:** [READY FOR BASELINING / NOT READY]

## Baseline Contents Summary

| Category | Count | ID Range |
|----------|-------|----------|
| Functional requirements | [N] | [FR-XX to FR-YY] |
| Non-functional requirements | [N] | [NFR-XX to NFR-YY] |
| **Total** | **[N]** | |

## Approvals

| Role | Name | Date | Decision |
|------|------|------|----------|
| Product Owner | [Name] | [Date] | [Approved / Conditional] |
| Technical Lead | [Name] | [Date] | [Approved / Conditional] |
| Project Manager | [Name] | [Date] | [Approved / Conditional] |
| QA Lead | [Name] | [Date] | [Approved / Conditional] |

## Known Issues and Deferred Items

| Item | Deferred To | Rationale |
|------|-------------|-----------|
| [Description] | [Release/Sprint] | [Why deferred] |
```

## Notes
- Do not baseline until all entry criteria pass.
- Use "Version X.Y draft Z" for drafts, "Version X.Y approved" for baselines.
- Every post-baseline change must go through the change control process.
