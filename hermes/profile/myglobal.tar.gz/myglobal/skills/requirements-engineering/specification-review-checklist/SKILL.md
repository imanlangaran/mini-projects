---
name: specification-review-checklist
description: Review requirements and SRS documents using structured checklists for quality attributes and defect detection. Use when inspecting individual requirements or an entire specification for completeness, correctness, and clarity.
intent: >-
  Provide structured checklists for reviewing both individual requirements and complete SRS documents. Use this during formal inspections, peer reviews, or self-reviews to systematically detect defects including ambiguity, incompleteness, incorrectness, inconsistency, and unverifiability. Covers the 10 characteristics of well-written individual requirements and the 8 characteristics of a well-written SRS, with a defect taxonomy for classifying findings.
type: component
theme: re-artifacts
best_for:
  - "Conducting formal or informal requirements inspections"
  - "Evaluating quality of individual requirements statements"
  - "Assessing completeness and consistency of an SRS document"
scenarios:
  - "I need to review an SRS before baselining and want a structured checklist"
  - "Requirements keep coming back from developers with questions about ambiguity"
  - "We want to establish a quality gate for requirements before they enter development"
estimated_time: "15-30 min per review session; 2-4 hours for full SRS review"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['review', 'checklist', 'defects']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Provide structured checklists for systematically reviewing individual requirements and complete SRS documents. Use this during inspections, peer reviews, or self-reviews to detect defects before requirements are baselined and handed to development.

This is not a process for running a review meeting -- it is a set of quality checklists. For the review process itself, see `../requirements-review-advisor/SKILL.md`.

## Key Concepts

### Characteristics of Well-Written Individual Requirements

Each individual requirement should exhibit these 10 attributes:

| # | Attribute | Definition | Test Question |
|---|-----------|-----------|---------------|
| 1 | Complete | Contains all necessary information | Can a developer implement this without asking questions? |
| 2 | Correct | Accurately represents a stakeholder need | Has a stakeholder confirmed this is what they need? |
| 3 | Feasible | Can be implemented within known constraints | Has the development team confirmed this is achievable? |
| 4 | Necessary | Traces to a business need or stakeholder request | What happens if we remove this requirement? |
| 5 | Prioritized | Has an assigned importance relative to others | Is this requirement ranked against competing requirements? |
| 6 | Unambiguous | Has exactly one interpretation | Can two readers interpret this differently? |
| 7 | Verifiable | Can be tested or demonstrated | Can I write a test case for this? (see `the requirements-testing skill (separate)`) |
| 8 | Consistent | Does not contradict other requirements | Does this conflict with any other requirement? |
| 9 | Modifiable | Can be changed without ripple effects | Is this requirement expressed once and cross-referenced? |
| 10 | Traceable | Has a unique ID and traces to source and tests | Can I trace this from stakeholder need to test case? |

### Characteristics of a Well-Written SRS

The SRS document as a whole should exhibit these 8 attributes:

| # | Attribute | Definition | Test Question |
|---|-----------|-----------|---------------|
| 1 | Complete | All requirements are present; no TBDs remain | Are there gaps, placeholders, or undefined sections? |
| 2 | Consistent | No requirements contradict each other | Do any two requirements specify conflicting behavior? |
| 3 | Modifiable | Organized for easy change without side effects | Is each requirement stated once and cross-referenced? |
| 4 | Traceable | Every requirement links forward and backward | Can every requirement be traced to source and to tests? |
| 5 | Correct | Every requirement accurately states a real need | Has the content been validated with stakeholders? |
| 6 | Ranked | Requirements are prioritized by importance | Are priorities assigned that guide implementation order? |
| 7 | Unambiguous | No requirement is subject to multiple interpretations | Has the document been reviewed by multiple readers? |
| 8 | Verifiable | Every requirement can be objectively verified | Can acceptance tests be written for every requirement? |

### Defect Taxonomy

Classify each finding during review:

| Defect Type | Definition | Example |
|-------------|-----------|---------|
| Ambiguity | Requirement can be interpreted in more than one way | "The system shall process transactions quickly" |
| Incompleteness | Requirement is missing information needed for implementation | "The system shall validate the input" (which input? what validation?) |
| Incorrectness | Requirement does not accurately reflect the stakeholder need | Requirement says 30-day alert but stakeholder needs 60-day |
| Inconsistency | Requirement contradicts another requirement in the SRS | Req 5.1 says 3-second response; Req 7.2 says 5-second response |
| Unverifiability | No objective way to determine if the requirement is met | "The system shall be intuitive" |
| Infeasibility | Requirement cannot be implemented within constraints | "The system shall respond in 1 millisecond for all queries" |
| Redundancy | Same requirement stated in multiple places with slight variations | Chemical name validation specified in three different sections |
| Gold-plating | Requirement adds functionality no stakeholder requested | Developer added "auto-suggest" feature not in any user story |

### Why This Works

Structured checklists catch defects that informal reading misses. Studies show that structured reviews find 2-3 times more defects per hour than ad hoc reviews. The checklist ensures reviewers examine each quality attribute explicitly rather than reading requirements as prose.

### Anti-Patterns
- **Review Without Checklist** -- Reading requirements like a novel instead of systematically checking quality attributes
- **Author Reviews Own Work** -- The person who wrote the requirements is the only reviewer (blind spots are invisible to the author)
- **Review Too Late** -- Reviewing the complete SRS only after months of writing instead of reviewing incrementally
- **Fix During Review** -- Attempting to fix defects during the review meeting instead of logging them and fixing afterwards

## Application

Use `template.md` for the consolidated review checklist.

### Step 1: Select Review Scope

Determine what is being reviewed:
- **Individual requirement review:** Apply the 10-attribute checklist to each requirement
- **SRS-level review:** Apply the 8-attribute checklist to the document as a whole
- **Focused review:** Review for a specific defect type (e.g., ambiguity pass, completeness pass)

### Step 2: Individual Requirement Review

For each requirement, evaluate against the 10 attributes:

```
Requirement ID: [ID]
Text: "[requirement text]"

[ ] Complete -- All information present for implementation?
[ ] Correct -- Validated with stakeholder?
[ ] Feasible -- Confirmed by development team?
[ ] Necessary -- Traces to a business need?
[ ] Prioritized -- Priority assigned?
[ ] Unambiguous -- Only one interpretation possible?
[ ] Verifiable -- Test case can be written?
[ ] Consistent -- No conflicts with other requirements?
[ ] Modifiable -- Stated once, cross-referenced elsewhere?
[ ] Traceable -- Has unique ID, source link, test link?
```

### Step 3: Check for Common Ambiguity Indicators

Flag requirements containing these words for closer inspection:

| Ambiguous Term | Problem | Fix |
|---------------|---------|-----|
| "appropriate" | Who decides what is appropriate? | Specify the criteria |
| "user-friendly" | Subjective, untestable | Define usability metrics |
| "fast" / "quickly" | No measurable threshold | Specify response time in seconds |
| "flexible" | Means different things to different people | Specify what must be configurable |
| "robust" | Vague quality claim | Specify error handling and recovery behavior |
| "seamless" | Undefined integration expectation | Specify the integration behavior explicitly |
| "etc." / "and so on" | Incomplete enumeration | List all items explicitly |
| "if possible" | Unclear commitment level | Make it a firm requirement or remove it |
| "should" (vs. "shall") | Ambiguous obligation | Use "shall" for mandatory, remove if optional |
| "support" | Does not specify what the system does | Specify the exact capability |

### Step 4: SRS-Level Review

Review the document as a whole:

```
[ ] Complete -- No TBD sections remain?
[ ] Complete -- All use cases have corresponding functional requirements?
[ ] Complete -- All data entities in ERD have corresponding data dictionary entries?
[ ] Consistent -- No conflicting requirements across sections?
[ ] Consistent -- Terminology used consistently throughout?
[ ] Modifiable -- Requirements stated once and cross-referenced?
[ ] Traceable -- Every requirement has a unique ID?
[ ] Traceable -- Traceability matrix links requirements to sources and tests?
[ ] Correct -- Content validated with stakeholders?
[ ] Ranked -- All requirements have priority assignments?
[ ] Unambiguous -- Glossary defines all domain terms?
[ ] Verifiable -- All quality attribute requirements have fit criteria?
```

### Step 5: Log Defects

For each finding, record:
- Requirement ID (or section for SRS-level findings)
- Defect type (from taxonomy)
- Severity (critical / major / minor)
- Description of the defect
- Suggested resolution

### Step 6: Calculate Review Metrics

Track review effectiveness:
- Defects found per page or per requirement
- Defect distribution by type (which types dominate?)
- Defect distribution by section (which sections have the most issues?)

---

## Examples

See `examples/sample.md` for a complete review of ChemTrack requirements using this checklist.

Mini example:

```markdown
## Requirement CT-FR-05
"The system should display search results in a user-friendly manner."

### Review Findings:
| Attribute | Pass? | Finding |
|-----------|-------|---------|
| Complete | NO | Does not specify what fields are displayed or how results are sorted |
| Unambiguous | NO | "User-friendly" has no objective definition |
| Verifiable | NO | Cannot write a test for "user-friendly manner" |
| Consistent | -- | No conflict detected |

### Defects Logged:
1. [Ambiguity] "User-friendly" -- Replace with specific layout and usability criteria
2. [Incompleteness] Missing specification of displayed fields, sort order, and pagination
3. [Unverifiability] No fit criterion for usability -- add measurable target

### Suggested Rewrite:
"The system shall display chemical search results in a table showing
chemical name, CAS number, location, and quantity, sorted by chemical
name ascending. The system shall display up to 50 results per page with
pagination controls."
```

## Common Pitfalls

### Pitfall 1: Checklist Fatigue
**Symptom:** Reviewers rush through the checklist, checking boxes without genuine evaluation.

**Consequence:** Defects pass through the review. Checklist becomes a formality.

**Fix:** Rotate reviewers, limit review sessions to 1-2 hours, and review in focused passes (one attribute at a time) rather than checking all 10 attributes per requirement in one pass.

---

### Pitfall 2: No Defect Classification
**Symptom:** Review findings are logged as free-text comments with no categorization.

**Consequence:** Cannot identify patterns (e.g., "80% of our defects are ambiguity"). Cannot measure improvement over time.

**Fix:** Use the defect taxonomy. Classify every finding by type and severity. Track statistics across reviews.

---

### Pitfall 3: Reviewing Too Much at Once
**Symptom:** A 200-page SRS is reviewed in a single marathon session.

**Consequence:** Review quality degrades after the first hour. Later sections get less scrutiny.

**Fix:** Review in increments of 15-20 pages or 30-50 requirements per session. Schedule multiple sessions.

---

### Pitfall 4: Skipping SRS-Level Review
**Symptom:** Individual requirements pass review but the SRS as a whole has gaps: missing use cases, inconsistent terminology, conflicting requirements across sections.

**Consequence:** The trees look fine but the forest is broken.

**Fix:** Conduct both individual requirement reviews and an SRS-level review. They catch different types of defects.

---

### Pitfall 5: No Follow-Up
**Symptom:** Defects are logged during review but never tracked to resolution.

**Consequence:** Review effort is wasted. Same defects persist into development.

**Fix:** Assign each defect to an owner with a resolution deadline. Re-review corrected requirements in the next cycle.

## References

### Related Skills
- `../requirements-review-advisor/SKILL.md` -- Process guidance for conducting review meetings
- `the requirements-testing skill (separate)` -- Testability verification complements specification review
- `../writing-requirements/SKILL.md` -- Writing techniques that produce reviewable requirements
- `the srs-document skill (separate)` -- The SRS structure being reviewed
- `../requirements-traceability/SKILL.md` -- Traceability is verified during SRS-level review

### External Frameworks
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 17: Beyond Requirements Development (reviews) and Chapter 11: Writing Excellent Requirements (quality attributes)
- IEEE 830-1998 -- Recommended Practice for Software Requirements Specifications (quality attributes)
- Tom Gilb & Dorothy Graham, *Software Inspection* (1993) -- Formal inspection process and checklists

---

**Skill type:** Component
**Dependencies:** References `the requirements-testing skill (separate)`, `the srs-document skill (separate)`
**Used by:** `../requirements-review-advisor/SKILL.md`, `the requirements-validation-process skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
