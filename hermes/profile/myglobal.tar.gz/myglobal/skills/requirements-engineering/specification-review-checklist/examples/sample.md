# Specification Review Checklist Example

## Example: ChemTrack SRS Review

```markdown
# Specification Review: ChemTrack SRS v1.0

**Date:** 2025-04-01
**Reviewer:** Maria Santos
**Document Reviewed:** ChemTrack SRS v1.0, Section 5 (Functional Requirements)

---

## Individual Requirement Reviews

### Requirement: CT-FR-05
"The system should display search results in a user-friendly manner."

| # | Attribute | Pass | Finding |
|---|-----------|------|---------|
| 1 | Complete | N | Missing: displayed fields, sort order, pagination |
| 2 | Correct | Y | Stakeholders confirm need for search display |
| 3 | Feasible | Y | Standard UI feature |
| 4 | Necessary | Y | Traces to UC-4 |
| 5 | Prioritized | N | No priority assigned |
| 6 | Unambiguous | N | "User-friendly" has no objective definition |
| 7 | Verifiable | N | Cannot write a test for "user-friendly manner" |
| 8 | Consistent | Y | No conflicts detected |
| 9 | Modifiable | Y | Stated once |
| 10 | Traceable | Y | ID assigned |

**Suggested Rewrite:**
"The system shall display chemical search results in a table showing chemical
name, CAS number, storage location, quantity, and expiration date, sorted by
chemical name ascending, with up to 50 results per page."

### Requirement: CT-FR-14
"The system shall validate that the CAS number follows the format NNN-NN-N
and passes the CAS check digit algorithm before saving."

| # | Attribute | Pass | Finding |
|---|-----------|------|---------|
| 1-10 | All | Y | Well-written: complete, unambiguous, verifiable, traceable |

**No defects. This is a model requirement.**

---

## SRS-Level Review

| # | Check | Pass | Finding |
|---|-------|------|---------|
| 1 | No TBD sections | N | Section 5.7 (Reporting) has two TBD items |
| 2 | All UCs have functional reqs | N | UC-9 (Dispose Chemical) has no requirements |
| 3 | No contradictions | N | CT-FR-09 says "appropriate personnel"; CT-FR-22 says "lab director" |
| 4 | Terminology consistent | N | "Chemical" and "reagent" used interchangeably |
| 5 | No redundant reqs | N | Name validation in CT-FR-03, -14, and -21 |
| 6 | All reqs have IDs | Y | All have CT-FR-nn format |
| 7 | Traceability matrix | N | No matrix present |
| 8 | Priorities assigned | N | 8 of 25 requirements lack priority |
| 9 | Glossary present | N | No glossary; SDS, CAS, EHS undefined |
| 10 | Fit criteria defined | N | Quality attributes use subjective terms |

---

## Defect Log

| # | Req ID | Type | Severity | Description | Fix |
|---|--------|------|----------|-------------|-----|
| D-01 | CT-FR-05 | Ambiguity | Major | "User-friendly" untestable | Replace with specific criteria |
| D-02 | CT-FR-05 | Incompleteness | Major | No field list or sort | Specify fields, sort, pagination |
| D-03 | CT-FR-09 | Ambiguity | Critical | "Appropriate personnel" undefined | Define recipients explicitly |
| D-04 | FR-09/22 | Inconsistency | Critical | Conflicting alert recipients | Reconcile with stakeholders |
| D-05 | SRS 5.7 | Incompleteness | Major | TBD in Reporting section | Complete with EHS input |
| D-06 | SRS | Incompleteness | Major | UC-9 has no functional reqs | Write disposal requirements |
| D-07 | SRS | Incompleteness | Major | No glossary | Create domain term glossary |

---

## Summary

- **Reviewed:** 25 functional requirements + SRS-level
- **Defects:** 7 (Critical: 2, Major: 5, Minor: 0)
- **Top types:** Incompleteness (4), Ambiguity (2), Inconsistency (1)
- **Recommendation:** Major revision needed. Critical defects must be resolved before baselining.
```

**Why this works:**
- Each requirement is checked against all 10 quality attributes
- The well-written requirement (CT-FR-14) shows the team what good looks like
- SRS-level review catches document-wide gaps invisible to individual reviews
- The inconsistency between CT-FR-09 and CT-FR-22 would only surface through systematic review
- Every defect is typed and severity-rated for pattern analysis
- Suggested rewrites demonstrate how to fix identified defects
