# Specification Review Checklist Template

Use this template for structured reviews of individual requirements and SRS documents.

## Template

```markdown
# Specification Review: [Project Name / Document Version]

**Date:** [YYYY-MM-DD]
**Reviewer:** [Name]
**Document Reviewed:** [SRS version, section, or requirement range]

---

## Individual Requirement Review

### Requirement: [ID] "[text]"

| # | Attribute | Pass | Finding |
|---|-----------|------|---------|
| 1 | Complete | Y/N | [Detail if N] |
| 2 | Correct | Y/N | [Detail if N] |
| 3 | Feasible | Y/N | [Detail if N] |
| 4 | Necessary | Y/N | [Detail if N] |
| 5 | Prioritized | Y/N | [Detail if N] |
| 6 | Unambiguous | Y/N | [Detail if N] |
| 7 | Verifiable | Y/N | [Detail if N] |
| 8 | Consistent | Y/N | [Detail if N] |
| 9 | Modifiable | Y/N | [Detail if N] |
| 10 | Traceable | Y/N | [Detail if N] |

*(Repeat for each requirement under review)*

---

## SRS-Level Review

| # | Check | Pass | Finding |
|---|-------|------|---------|
| 1 | No TBD sections remain | Y/N | [Detail] |
| 2 | All use cases have functional reqs | Y/N | [Detail] |
| 3 | No contradictions across sections | Y/N | [Detail] |
| 4 | Terminology used consistently | Y/N | [Detail] |
| 5 | No redundant requirements | Y/N | [Detail] |
| 6 | All requirements have unique IDs | Y/N | [Detail] |
| 7 | Traceability matrix present | Y/N | [Detail] |
| 8 | All priorities assigned | Y/N | [Detail] |
| 9 | Glossary present | Y/N | [Detail] |
| 10 | Fit criteria for quality attributes | Y/N | [Detail] |

---

## Defect Log

| # | Req ID | Type | Severity | Description | Fix | Owner |
|---|--------|------|----------|-------------|-----|-------|
| D-[n] | [ID] | [Type] | Crit/Maj/Min | [What is wrong] | [How to fix] | [Name] |

**Types:** Ambiguity, Incompleteness, Incorrectness, Inconsistency, Unverifiability, Infeasibility, Redundancy

---

## Summary

- **Reviewed:** [count] | **Defects:** [count] (Crit: [n], Maj: [n], Min: [n])
- **Recommendation:** [Accept / Accept with corrections / Major revision needed]
```

## Notes
- Review in sessions of 1-2 hours max. Classify every defect by type and severity.
