# Stakeholder Analysis Example

## Example: ChemTrack Lab Inventory System

```markdown
# Stakeholder Analysis: ChemTrack

**Date:** 2025-03-15
**Author:** Sarah Chen

---

## 1. User Classes

### User Class: Lab Technician (Favored)
- **Description:** Bench scientists who handle chemicals daily, enter data,
  run tests, record results
- **Frequency of Use:** Daily (6-8 hours)
- **Technical Skill:** Intermediate (comfortable with standard lab software)
- **Feature Subset:** Chemical lookup, inventory updates, expiration checks,
  usage logging
- **Priority:** Favored
- **Product Champion:** Maria Santos, Chemistry Dept, Building 3
- **Rationale:** Primary value driver. System must support daily bench
  operations efficiently or adoption will fail.

### User Class: Lab Director (Disfavored)
- **Description:** Department heads who review compliance reports and approve
  chemical purchases
- **Frequency of Use:** Weekly (1-2 hours for reports and approvals)
- **Technical Skill:** Novice with software, expert in chemistry
- **Feature Subset:** Dashboard, compliance reports, approval workflows
- **Priority:** Disfavored
- **Product Champion:** Dr. James Lee, Biology Dept
- **Rationale:** Important for sign-off but not the primary design target.
  Interface should serve technicians first; directors use a reporting subset.

### User Class: EHS Compliance Officer (Favored)
- **Description:** Environmental Health and Safety staff who generate
  regulatory reports and conduct safety audits
- **Frequency of Use:** Weekly for monitoring, quarterly for major reports
- **Technical Skill:** Intermediate
- **Feature Subset:** Report generation, audit trails, alert configuration
- **Priority:** Favored
- **Product Champion:** Tom Rivera, EHS Office
- **Rationale:** Regulatory compliance is a primary business driver (BO-1).
  Their needs are non-negotiable.

### User Class: External Auditors (Ignored)
- **Description:** State and federal auditors who review compliance data
- **Priority:** Ignored
- **Rationale:** Auditors receive exported PDF reports. No in-system UI
  designed for them. If audit-specific features are needed, revisit in
  Release 3.0.

---

## 2. Non-User Stakeholders

| Stakeholder | Role | Category | Power | Interest | Strategy |
|-------------|------|----------|-------|----------|----------|
| VP Research | Budget authority | Sponsor | High | Low | Keep Satisfied -- quarterly status |
| IT Security | System architecture review | Maintainer | High | High | Manage Closely -- weekly syncs |
| Procurement | Chemical ordering workflows | Domain Expert | Low | High | Keep Informed -- demo sessions |
| Legal Counsel | Contract and liability review | Regulator | High | Low | Keep Satisfied -- milestone reviews |

---

## 3. Power/Interest Grid

|               | Low Interest | High Interest |
|---------------|-------------|---------------|
| **High Power** | VP Research, Legal | IT Security |
| **Low Power**  | (none) | Procurement |

---

## 4. Engagement Plan

| Stakeholder | Engagement | Frequency | Channel | Escalation |
|-------------|-----------|-----------|---------|------------|
| Lab Technicians | Workshops, usability tests | Bi-weekly | In-person lab visits | Product Champion -> BA -> Sponsor |
| Lab Directors | Requirement reviews | Monthly | Email + demo | Product Champion -> BA -> VP Research |
| EHS Officers | Co-design sessions | Weekly | In-person + Slack | Direct to BA |
| IT Security | Architecture reviews | Weekly | Meetings | BA -> VP Research |
| VP Research | Status reporting | Quarterly | Email summary | N/A (final escalation point) |
```

**Why this works:**
- User classes are distinct with clear rationale for priority
- Product champions are named individuals, not generic roles
- Power/Interest grid drives differentiated engagement strategies
- Ignored user class (auditors) is explicitly documented with rationale
- Engagement plan matches intensity to stakeholder importance
