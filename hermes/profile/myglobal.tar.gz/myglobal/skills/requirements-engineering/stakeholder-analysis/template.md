# Stakeholder Analysis Template

Use this template to identify, classify, and plan engagement for all project stakeholders and user classes.

## Template

```markdown
# Stakeholder Analysis: [Project Name]

**Date:** [YYYY-MM-DD]
**Author:** [Name]

---

## 1. User Classes

### User Class: [Name]
- **Description:** [Who they are, what role they play]
- **Frequency of Use:** [Daily / Weekly / Monthly / Quarterly]
- **Technical Skill:** [Expert / Intermediate / Novice]
- **Feature Subset:** [Which features they primarily use]
- **Priority:** [Favored / Disfavored / Ignored]
- **Product Champion:** [Name and contact, or TBD]
- **Rationale for Priority:** [Why this classification]

*(Repeat for each user class)*

---

## 2. Non-User Stakeholders

| Stakeholder | Role | Category | Power | Interest | Engagement Strategy |
|-------------|------|----------|-------|----------|-------------------|
| [Name] | [Role] | Sponsor/Domain Expert/Regulator/Maintainer | H/L | H/L | [Strategy] |

---

## 3. Power/Interest Grid

|               | Low Interest | High Interest |
|---------------|-------------|---------------|
| **High Power** | [Names] | [Names] |
| **Low Power**  | [Names] | [Names] |

---

## 4. Engagement Plan

| Stakeholder/Class | Engagement Type | Frequency | Channel | Escalation Path |
|-------------------|----------------|-----------|---------|-----------------|
| [Name] | Reviews/Interviews/Sign-offs | [Frequency] | [Channel] | [Who resolves disputes] |

---

## 5. Open Questions
- [Stakeholder-related questions to resolve]
```

## Notes
- Every favored user class should have a named product champion.
- Revisit this analysis at each project milestone.
- The "Ignored" classification must include explicit rationale -- it is a decision, not an oversight.
