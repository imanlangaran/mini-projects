---
name: stakeholder-analysis
description: Identify and classify stakeholders, user classes, and their requirements influence. Use when starting a project to ensure all perspectives are represented and no critical voices are missed.
intent: >-
  Systematically identify all stakeholders and user classes for a software project, classify them by type and influence, and establish appropriate engagement strategies. Use this to avoid the costly mistake of discovering a key stakeholder late in the project, to resolve conflicting requirements by understanding each group's priorities, and to ensure the right people are involved at the right time.
type: component
theme: re-artifacts
best_for:
  - "Identifying all stakeholders before elicitation begins"
  - "Classifying user classes to prioritize conflicting needs"
  - "Establishing product champion roles for each user class"
scenarios:
  - "I'm starting a new project and need to know who to interview for requirements"
  - "Two user groups want conflicting features -- I need to understand their relative priority"
estimated_time: "30-60 min"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['stakeholder', 'user-classes', 'analysis']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Systematically identify all stakeholders and user classes for a software project, classify them by type and influence, and establish appropriate engagement strategies. Use this to avoid the costly mistake of discovering a key stakeholder late in the project, to resolve conflicting requirements by understanding each group's priorities, and to ensure the right people are involved at the right time.

This is not a simple contact list -- it is an analytical framework that drives who you talk to, whose needs take priority, and how conflicts get resolved.

## Key Concepts

### Stakeholder Categories
Not all stakeholders are equal. Classify them by relationship to the system:

- **Users** -- People who directly interact with the system
- **Customers** -- People who purchase or commission the system (may not be users)
- **Sponsors** -- People who fund and authorize the project
- **Domain experts** -- Subject matter experts who understand the business rules
- **Regulators** -- External parties imposing compliance constraints
- **Maintainers** -- People who will operate and maintain the system post-launch

### User Class Taxonomy
Users are not one group. Break them into classes based on:

- **Favored user classes** -- Whose needs take priority in design conflicts
- **Disfavored user classes** -- Who has access but is not designed for (e.g., auditors using an admin panel)
- **Ignored user classes** -- Explicitly not designing for these users (document why)

Each user class differs along dimensions:
- Frequency of use (daily vs. quarterly)
- Technical sophistication (expert vs. novice)
- Feature subset used
- Access privilege level
- Task criticality

### Product Champion Model
For each user class, identify a **product champion**:
- A real user who represents the class
- Has authority to make requirements decisions for that class
- Available for ongoing requirements elaboration and validation
- Not a manager speaking *for* users -- an actual practitioner

### Stakeholder Power/Interest Grid

|               | Low Interest | High Interest |
|---------------|-------------|---------------|
| **High Power** | Keep Satisfied | Manage Closely |
| **Low Power**  | Monitor | Keep Informed |

This grid determines engagement intensity: "Manage Closely" stakeholders get frequent reviews; "Monitor" stakeholders get periodic updates.

### Anti-Patterns
- **The Missing Stakeholder** -- Discovering a regulatory body or operations team after requirements are baselined
- **User Class Collapse** -- Treating all users as one homogeneous group
- **Proxy Problem** -- A manager claims to speak for users but has not done the actual work in years

## Application

Use `template.md` for the full fill-in structure.

### Step 1: Identify All Stakeholders

Start with a brainstorming pass. Use these prompts:
- Who will use the system directly?
- Who pays for or commissions the system?
- Who will maintain or operate the system?
- Who provides business rules or domain knowledge?
- Who imposes regulations or compliance requirements?
- Who will be affected if the system fails?
- Who provides or consumes data from the system?
- Who must approve requirements or sign off on the product?

List every name, role, and organization. Cast a wide net -- you can narrow later.

### Step 2: Classify User Classes

For each group of direct users, determine:

```
User Class: [Name]
Description: [Who they are, what they do]
Frequency of Use: [Daily / Weekly / Monthly / Quarterly]
Technical Skill: [Expert / Intermediate / Novice]
Feature Subset: [Which features they primarily use]
Priority: [Favored / Disfavored / Ignored]
Product Champion: [Specific person name, or TBD]
```

**Decision rule for priority:**
- If two user classes conflict, the **favored** class wins
- Favored status should reflect business value, not political power
- Document the rationale for priority assignments

### Step 3: Map Stakeholders to Power/Interest Grid

For each non-user stakeholder:
1. Rate their **power** (ability to influence project decisions): High / Low
2. Rate their **interest** (degree to which they care about the project): High / Low
3. Place them in the grid
4. Assign engagement strategy

### Step 4: Define Engagement Plan

For each stakeholder or user class, document:
- **Engagement type:** Reviews, interviews, workshops, sign-offs
- **Frequency:** Per sprint, monthly, milestone-based
- **Communication channel:** Email, meetings, Slack, demo sessions
- **Escalation path:** Who resolves disputes involving this stakeholder

### Step 5: Validate and Update

- Review the stakeholder list with the project sponsor
- Ask: "Who else should we be talking to?"
- Revisit quarterly or at each phase gate -- stakeholders change

---

## Examples

See `examples/sample.md` for a complete stakeholder analysis.

Mini example excerpt:

```markdown
## User Classes

### Favored: Lab Technician
- Frequency: Daily (8+ hours)
- Technical Skill: Intermediate
- Feature Subset: Sample entry, test execution, result recording
- Product Champion: Maria Santos (Building 3, Chem Lab)
- Rationale: Primary value driver; system must work for daily bench operations

### Disfavored: Lab Director
- Frequency: Weekly (for reports and approvals)
- Technical Skill: Novice with software
- Feature Subset: Dashboard, approval workflows, compliance reports
- Product Champion: Dr. James Lee

### Ignored: External Auditors
- Rationale: Access read-only compliance reports via export;
  not designing audit-specific UI in initial release
```

## Common Pitfalls

### Pitfall 1: Treating All Users as One Group
**Symptom:** Requirements say "the user" throughout, with no class distinction.

**Consequence:** Design optimized for no one. Power users find it too slow; novices find it too complex.

**Fix:** Identify at least 2-3 distinct user classes. Even "admin" vs. "end user" is a start.

---

### Pitfall 2: No Product Champion
**Symptom:** Requirements decisions are made by managers, architects, or the BA without direct user input.

**Consequence:** Requirements reflect what management *thinks* users need, not what they actually need.

**Fix:** Assign a real practitioner from each favored user class as product champion. If you cannot get access to real users, escalate -- this is a project risk.

---

### Pitfall 3: Ignoring Disfavored Users Entirely
**Symptom:** Disfavored or ignored user classes are literally ignored -- no documentation of the decision.

**Consequence:** Surprise requirements late in the project when someone asks "what about auditors?"

**Fix:** Document ignored user classes explicitly with rationale. This is a conscious decision, not an oversight.

---

### Pitfall 4: Static Stakeholder List
**Symptom:** Stakeholder analysis done once at project start, never revisited.

**Consequence:** New stakeholders emerge (regulatory changes, organizational restructuring) and are not engaged.

**Fix:** Review stakeholders at each milestone. Add a standing agenda item to sprint retrospectives: "Any new stakeholders?"

## References

### Related Skills
- `../vision-and-scope/SKILL.md` -- Stakeholder analysis feeds stakeholder profiles in the vision and scope document
- `../requirements-elicitation-workshop/SKILL.md` -- Use stakeholder analysis to decide who to invite to elicitation sessions
- `the use-case skill (separate)` -- User classes become the actors in use cases

### External Frameworks
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 6: Finding the Voice of the User
- Eden & Ackermann, *Making Strategy* (1998) -- Power/Interest grid
- Suzanne Robertson, *Mastering the Requirements Process* (2012) -- Stakeholder identification

---

**Skill type:** Component
**Dependencies:** None (foundational skill)
**Used by:** `../vision-and-scope/SKILL.md`, `../requirements-elicitation-workshop/SKILL.md`, `the use-case skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
