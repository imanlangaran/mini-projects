---
name: moscow-prioritization
description: Categorize requirements into Must/Should/Could/Won't buckets with allocation guidelines. Use when timeboxed delivery requires clear scope boundaries and stakeholder alignment on what is in vs. out.
intent: >-
  Guide requirements engineers through the MoSCoW prioritization method to categorize requirements into four distinct buckets with clear definitions and allocation guidelines. Use this when working with timeboxed iterations, when stakeholders need a simple framework to agree on scope, or when release planning requires explicit inclusion/exclusion decisions. Includes the 60/20/20 allocation rule and guidelines for when MoSCoW is appropriate vs. when a more quantitative method is needed.
type: component
theme: re-artifacts
best_for:
  - "Timeboxed delivery where scope must be fixed to a timebox"
  - "Getting stakeholder consensus on what is in vs. out for a release"
  - "Agile release planning where simplicity and speed are valued over precision"
scenarios:
  - "We have a fixed deadline and need stakeholders to agree on minimum viable scope"
  - "The product owner wants a quick categorization of 20 backlog items for the next sprint"
  - "Stakeholders keep adding requirements -- I need a framework to push back on scope creep"
estimated_time: "30-45 min"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['moscow', 'prioritization', 'mvp', 'scope']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining', 'requirements-traceability']
---


## Purpose
Guide requirements engineers through the MoSCoW prioritization method to categorize all requirements into four clear buckets -- Must Have, Should Have, Could Have, and Won't Have -- with explicit definitions and allocation guidelines. This is the simplest defensible prioritization framework and works best for timeboxed delivery.

This is not "High/Medium/Low" with different labels. The key distinction is that MoSCoW ties directly to delivery commitments: Must Haves define the minimum usable subset, and Won't Haves are explicit scope exclusions, not "maybe later."

## Key Concepts

### The Four Categories

| Category | Definition | Commitment |
|----------|-----------|------------|
| **Must Have (Mo)** | Non-negotiable for this timebox. Without these, the delivery is a failure. | Guaranteed delivery |
| **Should Have (S)** | Important but not critical. The system is usable without them, though painful. | Expected delivery -- included unless something goes wrong |
| **Could Have (Co)** | Desirable but not important. Nice-to-have features that improve user experience. | Delivered only if time permits |
| **Won't Have (W)** | Explicitly excluded from this timebox. Not forgotten -- consciously deferred. | Not delivered this timebox; may be reconsidered later |

### The 60/20/20 Allocation Rule

For a given timebox, allocate estimated effort as:
- **Must Have:** No more than 60% of total effort
- **Should Have:** Approximately 20% of total effort
- **Could Have:** Approximately 20% of total effort
- **Won't Have:** 0% (excluded from the timebox)

This creates a **contingency buffer** of ~40%. If things go wrong (and they will), Should Haves and Could Haves can be dropped without failing the delivery. If Must Haves consume 100% of capacity, the project has zero margin for error.

### Must Have Litmus Test

A requirement is Must Have **only** if:
- The delivery is useless without it (not just less convenient -- useless)
- There is no workaround, even a manual or temporary one
- Without it, the project should not go live
- It is required by regulation, contract, or safety

If a workaround exists, it is Should Have at most.

### Why This Works
- **Binary decisions** -- Each requirement is either in a category or not. No ambiguity.
- **Built-in contingency** -- The 60/20/20 rule ensures the plan has slack for reality.
- **Explicit exclusions** -- Won't Have prevents scope creep by documenting what was intentionally excluded and why.
- **Stakeholder-friendly** -- The categories are intuitive. No formulas or spreadsheets needed.

### When MoSCoW Works vs. When It Does Not

**Works well when:**
- Requirements are at a similar level of abstraction
- There is a fixed timebox or deadline
- Stakeholders are collaborative and willing to make trade-offs
- The number of requirements is manageable (10-50)

**Does not work well when:**
- Stakeholders insist everything is "Must Have" (use `the value-cost-risk-analysis skill (separate)` instead)
- You need fine-grained priority ordering (rank 1 through N)
- Requirements have complex interdependencies that the four buckets cannot capture
- Political dynamics prevent honest categorization

### Anti-Patterns
- **Everything is Must Have** -- If more than 60% of effort is Must Have, the categorization is broken. Revisit with the litmus test.
- **Won't Have as a Dumping Ground** -- Won't Have means "explicitly excluded with documented rationale," not "we did not get around to discussing this."
- **No Effort Estimates** -- MoSCoW without effort estimates is just labeling. You need estimates to validate the 60/20/20 allocation.

## Application

Use `template.md` for the full categorization structure.

### Step 1: Prepare the Requirements List

Gather all candidate requirements for the timebox. Each should have:
- A unique identifier
- A short description
- A rough effort estimate (story points, T-shirt size, or ideal days)

### Step 2: Define the Timebox Constraints

Document:
- **Timebox duration:** e.g., 3-month release, 2-week sprint
- **Total available effort:** e.g., 200 story points, 4 developer-months
- **Hard constraints:** Regulatory deadlines, contractual commitments, event-driven dates

### Step 3: Apply the Must Have Litmus Test

For each requirement, ask:
1. "If this is not delivered, is the release useless?" -- If no, it is not Must Have.
2. "Is there any workaround, even temporary?" -- If yes, it is not Must Have.
3. "Is this required by regulation or contract?" -- If yes, it is Must Have.

For ChemTrack Release 1, Must Haves include: chemical inventory CRUD operations, expiration alerting, and regulatory compliance reporting. A barcode scanning feature is convenient but has a manual workaround (keyboard entry), so it is Should Have.

### Step 4: Categorize Should Have and Could Have

For remaining requirements:
- **Should Have** -- "We would be embarrassed to release without this, but the system technically works."
- **Could Have** -- "Users would appreciate this, but they can live without it."

### Step 5: Validate the 60/20/20 Allocation

Sum the effort estimates for each category:

```
Must Have total:   120 story points (60% of 200 = 120) -- at the limit
Should Have total:  45 story points (22.5%) -- acceptable
Could Have total:   35 story points (17.5%) -- acceptable
Won't Have total:   50 story points (excluded from this release)
```

If Must Have exceeds 60%, either:
1. Move marginal Must Haves to Should Have (apply the litmus test more strictly)
2. Reduce the scope of a Must Have requirement
3. Extend the timebox (last resort)

### Step 6: Document Won't Haves with Rationale

For every Won't Have, record:
- Why it was excluded
- When it might be reconsidered (e.g., Release 2, pending customer feedback)
- Any stakeholder who disagreed (for traceability)

### Step 7: Get Stakeholder Sign-Off

Present the categorization to all stakeholders. The key agreement is:
- "Must Haves are guaranteed. Should Haves are expected. Could Haves are best-effort. Won't Haves are out."
- Any Must Have that fails the litmus test should be challenged in this review.

---

## Examples

See `examples/sample.md` for a complete MoSCoW categorization.

Mini example excerpt:

```markdown
## Must Have (60% capacity target)
- FR-01: Add/edit/delete chemical records (20 pts)
- FR-12: Expiration date alerting (15 pts)
- FR-15: Regulatory compliance report generation (25 pts)
Total: 60 pts / 120 available = 50% -- under the 60% cap

## Should Have (20% capacity target)
- FR-08: Barcode scanning for chemical entry (15 pts)
- FR-22: Dashboard for lab directors (10 pts)

## Could Have (20% capacity target)
- FR-30: Mobile-friendly interface (12 pts)
- FR-35: Bulk import from spreadsheet (8 pts)

## Won't Have (this release)
- FR-40: Integration with procurement system
  Rationale: Procurement API not available until Q4. Revisit for Release 2.
```

## Common Pitfalls

### Pitfall 1: "Everything is Must Have"
**Symptom:** 80%+ of effort is categorized as Must Have.

**Consequence:** No contingency buffer. Any delay or discovery causes the release to miss its date or cut features without a framework for deciding which ones.

**Fix:** Apply the litmus test ruthlessly. Ask: "If we ship without this one feature, do we cancel the release?" If the answer is no, it is not Must Have.

---

### Pitfall 2: Skipping Effort Estimates
**Symptom:** Requirements are categorized without any estimation of size or effort.

**Consequence:** The 60/20/20 allocation cannot be validated. A category might contain 90% of effort without anyone realizing it.

**Fix:** Rough estimates are sufficient. T-shirt sizes (S/M/L/XL) or relative story points work fine. Precision is not the goal -- proportion validation is.

---

### Pitfall 3: Won't Have Without Rationale
**Symptom:** Won't Have is a list of items with no explanation.

**Consequence:** Stakeholders forget why something was excluded. The same items come back as requests, consuming meeting time. Or worse, a Won't Have item was actually important and was excluded by accident.

**Fix:** Every Won't Have needs a one-sentence rationale and a "revisit" timeline.

---

### Pitfall 4: Treating MoSCoW as a One-Time Exercise
**Symptom:** Categorization done at project start, never revisited.

**Consequence:** Market changes, technical discoveries, or stakeholder departures make the original categorization stale.

**Fix:** Recategorize at each timebox boundary (release, PI boundary, major sprint). Priorities shift -- the framework should shift with them.

## References

### Related Skills
- `the value-cost-risk-analysis skill (separate)` -- More quantitative alternative when MoSCoW is too coarse or stakeholders cannot agree
- `the requirements-status-tracking skill (separate)` -- Track implementation progress of each MoSCoW category
- `../requirements-baselining/SKILL.md` -- Baseline the agreed MoSCoW categorization
- `the change-impact-analysis skill (separate)` -- Assess impact when a requirement changes MoSCoW category

### External Frameworks
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 16: First Things First: Setting Requirement Priorities
- Dai Clegg & Richard Barker, *Case Method Fast-Track: A RAD Approach* (1994) -- Original MoSCoW definition
- DSDM Consortium, *DSDM Atern Handbook* (2008) -- MoSCoW in the context of timeboxed delivery

---

**Skill type:** Component
**Dependencies:** None (standalone method)
**Used by:** `the value-cost-risk-analysis skill (separate)`, `the requirements-status-tracking skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
