# MoSCoW Prioritization Template

Use this template to categorize requirements into Must/Should/Could/Won't buckets with effort validation.

## Template

```markdown
# MoSCoW Prioritization: [Project Name]

**Date:** [YYYY-MM-DD]
**Author:** [Name]
**Timebox:** [Release/Sprint identifier and duration]
**Total Available Effort:** [Story points / hours / days]

---

## Must Have -- Target: <= 60% of effort ([X] points max)

| Req ID | Requirement | Effort Est. | Litmus Test Justification |
|--------|-------------|-------------|---------------------------|
| [ID]   | [Description] | [Est.] | [Why this is non-negotiable] |
| **Subtotal** | | **[Sum]** | **[Sum/Total]%** |

## Should Have -- Target: ~20% of effort ([X] points)

| Req ID | Requirement | Effort Est. | Workaround if Dropped |
|--------|-------------|-------------|----------------------|
| [ID]   | [Description] | [Est.] | [What users do instead] |
| **Subtotal** | | **[Sum]** | **[Sum/Total]%** |

## Could Have -- Target: ~20% of effort ([X] points)

| Req ID | Requirement | Effort Est. | Value if Included |
|--------|-------------|-------------|-------------------|
| [ID]   | [Description] | [Est.] | [Benefit to users] |
| **Subtotal** | | **[Sum]** | **[Sum/Total]%** |

## Won't Have (This Timebox)

| Req ID | Requirement | Rationale for Exclusion | Revisit Timeline |
|--------|-------------|------------------------|-----------------|
| [ID]   | [Description] | [Why excluded] | [When to reconsider] |

---

## Allocation Summary

| Category | Effort | % of Total | Target % | Status |
|----------|--------|-----------|----------|--------|
| Must Have | [Sum] | [%] | <= 60% | [OK / Over] |
| Should Have | [Sum] | [%] | ~20% | [OK / Over] |
| Could Have | [Sum] | [%] | ~20% | [OK / Over] |
| Won't Have | [Sum] | N/A | N/A | Excluded |

## Sign-Off

| Role | Name | Date | Agreement |
|------|------|------|-----------|
| [Role] | [Name] | [Date] | Agree / Disagree (note concerns) |
```

## Notes
- Apply the Must Have litmus test: "Is the release useless without this? Is there no workaround?"
- If Must Have exceeds 60%, re-examine with stricter litmus test criteria.
- Every Won't Have needs a rationale and revisit timeline.
