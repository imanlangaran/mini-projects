# MoSCoW Prioritization Example

## Example: ChemTrack Lab Inventory System -- Release 1

```markdown
# MoSCoW Prioritization: ChemTrack

**Date:** 2025-04-05
**Author:** Sarah Chen (Business Analyst)
**Timebox:** Release 1 (12 weeks, Sprints 1-6)
**Total Available Effort:** 200 story points

---

## Timebox Constraints
- **Duration:** 12 weeks (6 two-week sprints)
- **Team capacity:** 200 story points (2 developers + 1 QA, ~33 pts/sprint)
- **Hard deadlines:** State EPA compliance audit scheduled for Week 16;
  compliance features must be operational with buffer for testing
- **External dependencies:** Barcode scanner hardware requires 6-week
  procurement lead time (not yet ordered)

---

## Must Have -- Target: <= 120 points (60%)

| Req ID | Requirement | Effort | Litmus Test Justification |
|--------|-------------|--------|---------------------------|
| FR-01 | Add/edit/delete chemical records | 20 pts | Core CRUD -- system is useless without it |
| FR-05 | Chemical search with filters | 13 pts | Cannot locate chemicals without search; no workaround at scale |
| FR-12 | Expiration date alerting | 15 pts | Safety requirement; expired chemicals are a lab hazard |
| FR-15 | Regulatory compliance report generation | 25 pts | EPA audit in Week 16; contractual obligation |
| FR-22 | Hazard classification display | 8 pts | GHS compliance; required for lab safety |
| FR-42 | Audit trail logging | 13 pts | Required by compliance reports; no manual alternative |
| FR-38 | User role management | 10 pts | Security baseline; cannot go live without access control |
| **Subtotal** | | **104 pts** | **52% of 200 -- under 60% cap** |

---

## Should Have -- Target: ~40 points (20%)

| Req ID | Requirement | Effort | Workaround if Dropped |
|--------|-------------|--------|-----------------------|
| FR-33 | SDS document linking | 12 pts | Technicians manually look up SDS on manufacturer websites |
| FR-25 | Chemical disposal tracking | 15 pts | Track disposal on paper forms; enter into system in Release 2 |
| FR-35 | Location/storage tracking | 13 pts | Maintain current spreadsheet for locations; integrate later |
| **Subtotal** | | **40 pts** | **20% of 200 -- on target** |

---

## Could Have -- Target: ~40 points (20%)

| Req ID | Requirement | Effort | Value if Included |
|--------|-------------|--------|-------------------|
| FR-18 | Dashboard for lab directors | 18 pts | Directors get at-a-glance view; otherwise use standard reports |
| FR-28 | Bulk import from spreadsheet | 15 pts | Faster initial data migration; otherwise manual entry |
| **Subtotal** | | **33 pts** | **16.5% of 200 -- acceptable** |

---

## Won't Have (This Release)

| Req ID | Requirement | Rationale for Exclusion | Revisit Timeline |
|--------|-------------|------------------------|-----------------|
| FR-08 | Barcode scanning | Hardware procurement needs 6-week lead time; not ordered. Manual entry workaround exists. | Release 2 (Q3) -- order hardware now |
| FR-30 | Mobile-friendly interface | High effort (30 pts) for moderate benefit. Desktop access sufficient for lab environments. | Release 2 -- evaluate after user adoption data |
| FR-40 | Procurement integration | Procurement system API not available until Q4. External dependency blocks delivery. | Release 2 or 3 -- dependent on procurement API timeline |

---

## Allocation Summary

| Category | Effort | % of Total | Target % | Status |
|----------|--------|-----------|----------|--------|
| Must Have | 104 pts | 52% | <= 60% | OK -- 8% buffer |
| Should Have | 40 pts | 20% | ~20% | OK -- on target |
| Could Have | 33 pts | 16.5% | ~20% | OK -- slightly under |
| Won't Have | ~55 pts | N/A | N/A | Excluded |
| **Total Committed** | **177 pts** | **88.5%** | | **23 pts contingency** |

**Contingency analysis:** 23 points of uncommitted capacity provides a buffer
for scope adjustments. If a Must Have takes longer than estimated, Could Haves
are dropped first, then Should Haves. The 104-point Must Have commitment has
an additional 16-point buffer before it would hit the 60% ceiling.

---

## Sign-Off

| Role | Name | Date | Agreement |
|------|------|------|-----------|
| Product Champion | Maria Santos | 2025-04-06 | Agree |
| Lab Director | Dr. James Lee | 2025-04-06 | Agree -- requests FR-18 dashboard be first Could Have if capacity allows |
| EHS Officer | Tom Rivera | 2025-04-06 | Agree -- confirms compliance requirements are all Must Have |
| Technical Lead | Sarah Chen | 2025-04-07 | Agree |
| Project Manager | Mike Johnson | 2025-04-07 | Agree |
```

**Why this works:**
- Must Have items pass the litmus test: each is either core functionality or regulatory
- Must Have effort is 52%, well under the 60% ceiling, providing contingency
- Should Have items have documented workarounds if they must be dropped
- Won't Have items have clear rationale and revisit timelines
- Allocation summary validates the 60/20/20 distribution
- Total committed effort (177/200) leaves a 23-point contingency buffer
