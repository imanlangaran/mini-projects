---
name: requirements-traceability
description: Build and maintain a requirements traceability matrix linking business objectives, requirements, design, and tests. Use when you need to demonstrate coverage, perform impact analysis, or satisfy regulatory audit requirements.
intent: >-
  Create a traceability matrix that establishes bidirectional links between business objectives, requirements, design elements, and test cases. Use this to answer four critical questions: (1) Does every requirement trace to a business need? (2) Does every business need have requirements? (3) What is affected when a requirement changes? (4) Is every requirement tested? Traceability is essential for impact analysis, coverage verification, and regulatory compliance.
type: component
theme: re-artifacts
best_for:
  - "Demonstrating that all business needs are covered by requirements"
  - "Performing change impact analysis across the requirements chain"
  - "Satisfying regulatory audit requirements for traceability"
scenarios:
  - "A stakeholder wants to change a business objective -- I need to know which requirements are affected"
  - "I need to prove to an auditor that every requirement has a corresponding test case"
estimated_time: "60-90 min initial setup; 5-10 min per update"
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: ['traceability', 'matrix', 'sdd', 'impact-analysis']
    category: requirements-engineering
    related_skills: ['requirements-elicitation-workshop', 'elicitation-interview', 'stakeholder-analysis', 'elicitation-technique-selector', 'writing-requirements', 'user-story-re', 'acceptance-criteria', 'quality-attribute', 'moscow-prioritization', 'vision-and-scope', 'requirements-review-advisor', 'specification-review-checklist', 'requirements-baselining']
---


## Purpose
Create a traceability matrix that establishes bidirectional links between business objectives, requirements, design elements, and test cases. Use this to answer the four questions that traceability exists to serve:

1. **Forward from source:** Which requirements implement this business objective?
2. **Backward to source:** Which business objective does this requirement serve?
3. **Forward to implementation:** Which design/code/test covers this requirement?
4. **Impact analysis:** If X changes, what else is affected?

## Key Concepts

### Traceability Chain
```
Business Objectives (Vision & Scope)
    |
    v
User Requirements (Use Cases / User Stories)
    |
    v
Functional Requirements (SRS)
    |
    v
Design Elements (Architecture / Components)
    |
    v
Test Cases (Test Plan)
```

Each link is bidirectional. You should be able to trace forward (objective -> requirement -> test) and backward (test -> requirement -> objective).

### Types of Traceability Links

| Link Type | From | To | Purpose |
|-----------|------|-----|---------|
| **Source trace** | Business objective | User requirement | Ensure every business need is addressed |
| **Requirement trace** | User requirement | Functional requirement | Ensure user needs decompose to system behavior |
| **Design trace** | Functional requirement | Design element | Ensure every requirement is designed |
| **Test trace** | Functional requirement | Test case | Ensure every requirement is tested |
| **Dependency trace** | Requirement | Requirement | Track inter-requirement dependencies |

### Traceability Matrix Formats

**Simple two-column trace:**
| Requirement | Test Case(s) |
|-------------|-------------|
| FR-001 | TC-001, TC-002 |

**Full chain matrix:**
| Business Obj | User Req | Functional Req | Test Case | Status |
|-------------|----------|---------------|-----------|--------|
| BO-1 | UC-3 | CT.CATALOG.SEARCH.1 | TC-101 | Verified |

**N-to-M matrix (coverage view):**
| | BO-1 | BO-2 | BO-3 |
|---|------|------|------|
| FR-001 | X | | |
| FR-002 | X | X | |
| FR-003 | | | X |

### Traceability Red Flags
- **Requirement with no source** -- Where did this come from? It may be gold-plating.
- **Business objective with no requirements** -- A stated goal with no implementation path.
- **Requirement with no test** -- An untestable or untested requirement.
- **Orphan test case** -- A test that does not trace to any requirement (testing what?).

### Anti-Patterns
- **Trace Everything to Everything** -- Links that are too loose to be meaningful. Every requirement traces to "improve user experience."
- **Trace Once, Never Update** -- Traceability matrix created at start, never maintained as requirements change.
- **Tool Without Process** -- Having a requirements tool but no process for maintaining trace links.

## Application

### Step 1: Establish the Traceability Structure

Decide what artifacts to trace:
- **Minimum:** Business Objectives <-> Functional Requirements <-> Test Cases
- **Standard:** Business Objectives <-> User Requirements <-> Functional Requirements <-> Test Cases
- **Full:** Add Design Elements and Code Components to the chain

### Step 2: Create the Matrix

For each functional requirement:
1. Link backward to its source (user requirement, business objective)
2. Link forward to its test case(s)
3. Record the current status

Use `template.md` for the structure.

### Step 3: Analyze Coverage

Run these checks:

**Forward coverage (no gaps):**
- Every business objective should have at least one requirement
- Every requirement should have at least one test case

**Backward coverage (no gold-plating):**
- Every requirement should trace to at least one business objective
- Every test case should trace to at least one requirement

**Completeness metrics:**
- Coverage = (requirements with traces / total requirements) * 100%
- Target: 100% for both forward and backward traces

### Step 4: Perform Impact Analysis

When a requirement changes:
1. Find the requirement in the matrix
2. Trace forward: Which test cases need updating?
3. Trace backward: Does the change align with the business objective?
4. Trace laterally: Which other requirements depend on this one?
5. Document the impact scope in the change request

### Step 5: Maintain Over Time

- Update traces when requirements are added, changed, or deleted
- Review the matrix at each milestone or sprint review
- Track traceability metrics: coverage percentage, broken links
- Assign ownership: someone must be responsible for maintaining traces

---

## Examples

See `examples/sample.md` for a complete traceability matrix.

Mini example:

```markdown
| Business Obj | User Req | Functional Req | Test Case | Status |
|-------------|----------|---------------|-----------|--------|
| BO-1: Reduce reporting time | UC-8: Generate Report | CT.REPORT.GEN.1: Generate EPA report within 30s | TC-201: EPA report generation load test | Verified |
| BO-2: Eliminate expired chemicals | UC-5: Alert Expiration | CT.ALERT.EXPIRY.1: Send 30-day alert | TC-150: 30-day alert email verification | Verified |
| BO-2 | UC-5 | CT.ALERT.EXPIRY.2: Send 7-day urgent alert | TC-151: 7-day urgent alert verification | Implemented |
| -- | -- | CT.CATALOG.ADD.3: Allow bulk import from CSV | -- | Proposed |
```

**Analysis of this mini example:**
- CT.CATALOG.ADD.3 has no backward trace to a business objective (possible gold-plating)
- CT.CATALOG.ADD.3 has no test case yet (needs test planning)
- BO-1 and BO-2 have forward coverage through requirements and tests

## Common Pitfalls

### Pitfall 1: Requirements Without Sources
**Symptom:** Several requirements have no backward trace to a business objective or user need.

**Consequence:** These may be gold-plating -- features nobody asked for that consume development resources.

**Fix:** For each untraced requirement, ask: "Which business objective does this serve?" If none, either find the missing objective or remove the requirement.

---

### Pitfall 2: Matrix Not Maintained
**Symptom:** The traceability matrix was created at project start and has not been updated since. New requirements have no traces.

**Consequence:** The matrix is useless for impact analysis. Changes are evaluated without understanding the full chain.

**Fix:** Make traceability updates a required step in the change control process. No requirement change is complete until traces are updated.

---

### Pitfall 3: No Forward Trace to Tests
**Symptom:** Requirements exist without corresponding test cases.

**Consequence:** These requirements are never verified. Defects in these areas are discovered by users in production.

**Fix:** Every requirement should have at least one test case before it is marked "Verified." Use the matrix to identify untested requirements and assign test case creation.

## References

### Related Skills
- `../vision-and-scope/SKILL.md` -- Business objectives that serve as trace sources
- `the srs-document skill (separate)` -- Functional requirements that are traced
- `the requirements-management-process skill (separate)` -- Traceability is maintained as part of requirements management
- `the change-control-advisor skill (separate)` -- Impact analysis uses traceability

### External Frameworks
- Karl Wiegers & Joy Beatty, *Software Requirements, Third Edition* (2013) -- Chapter 27: Requirements Management Practices
- IEEE 830 / ISO/IEC/IEEE 29148 -- Requirements traceability guidance
- CMMI -- Requirements Management process area

---

**Skill type:** Component
**Dependencies:** References `../vision-and-scope/SKILL.md`, `the srs-document skill (separate)`
**Used by:** `the requirements-management-process skill (separate)`, `the change-control-advisor skill (separate)`

---

> **Provenance:** Adapted from the `jdm4pku/RE-Skills` catalog (educational/professional use; grounded in Karl Wiegers & Joy Beatty, *Software Requirements*).
