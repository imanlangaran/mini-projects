# Requirements Traceability Example

## Example: ChemTrack Traceability Matrix (Excerpt)

```markdown
# Requirements Traceability Matrix: ChemTrack

**Version:** 1.0
**Date:** 2025-04-15

---

## Full Chain Traceability

| Business Obj | User Req | Functional Req | Test Case | Status |
|-------------|----------|---------------|-----------|--------|
| BO-1: Reduce report time from 3 days to 4 hours | UC-8: Generate Compliance Report | CT.REPORT.GEN.1: Generate EPA report in 30s for 50K records | TC-201: EPA report - standard load | Verified |
| BO-1 | UC-8 | CT.REPORT.GEN.2: Support EPA and state report formats | TC-202: State format validation | Verified |
| BO-1 | UC-4: Search Catalog | CT.CATALOG.SEARCH.1: Search by name, CAS, location, date | TC-101: Multi-criteria search | Verified |
| BO-1 | UC-4 | CT.CATALOG.SEARCH.2: Results within 2 seconds | TC-102: Search performance | Verified |
| BO-2: Eliminate expired chemicals | UC-3: Add Chemical | CT.CATALOG.ADD.1: Validate CAS format | TC-103: CAS validation | Verified |
| BO-2 | UC-5: Alert Expiration | CT.ALERT.EXPIRY.1: Send 30-day email alert | TC-150: 30-day alert | Verified |
| BO-2 | UC-5 | CT.ALERT.EXPIRY.2: Send 7-day urgent alert | TC-151: 7-day urgent alert | Implemented |
| BO-2 | UC-5 | CT.ALERT.EXPIRY.3: Display EXPIRED banner, block usage | TC-152: Expired chemical blocking | Implemented |
| BO-3: 90% lab manager adoption | UC-3 | CT.CATALOG.ADD.2: Detect and handle duplicate CAS entries | TC-104: Duplicate detection | Approved |
| BO-4: Reduce safety incidents to 0 | UC-5 | CT.ALERT.EXPIRY.1 | TC-150 | (shared) |
| BO-4 | UC-9: Dispose Chemical | CT.DISP.1: Require EHS approval for hazardous | TC-160: Hazmat disposal approval | Approved |
| -- | -- | CT.CATALOG.ADD.3: Allow bulk CSV import | -- | Proposed |

---

## Coverage Analysis

### Forward Coverage
| Business Objective | Req Count | All Tested? | Coverage |
|-------------------|-----------|-------------|----------|
| BO-1: Reduce report time | 4 | Yes | 100% |
| BO-2: Eliminate expired | 4 | Partial (2/4 verified) | 100% traced, 50% verified |
| BO-3: 90% adoption | 1 | No (approved only) | 100% traced |
| BO-4: Safety incidents | 2 | Partial | 100% traced |

### Orphan Analysis
- **Requirements without sources:** CT.CATALOG.ADD.3 (bulk CSV import) -- 
  No business objective. Requested by lab director informally. 
  Action: Either link to BO-3 (adoption) or defer.
- **Requirements without tests:** CT.CATALOG.ADD.2, CT.DISP.1 -- 
  In Approved status, test cases pending.
- **Test cases without requirements:** None
- **Business objectives without requirements:** None

---

## Impact Analysis Example

| Change Request | Req Changed | Affected Reqs | Affected Tests | Notes |
|---------------|-------------|--------------|----------------|-------|
| CR-005: Change alert timing from 30 to 45 days | CT.ALERT.EXPIRY.1 | CT.ALERT.EXPIRY.2 (7-day), CT.STATE.1 (state model) | TC-150, TC-151 | Also update BR-011 (alert timing rule) |
```

**Why this works:**
- Full chain from business objectives through test cases
- Coverage analysis shows exactly where gaps are
- Orphan analysis caught a gold-plated requirement (bulk CSV import)
- Impact analysis demonstrates how traceability enables change management
- Status tracking shows progress through the development lifecycle
