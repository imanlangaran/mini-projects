# Requirements Traceability Template

Use this template to create and maintain a requirements traceability matrix.

## Template

```markdown
# Requirements Traceability Matrix: [Project Name]

**Version:** [x.y]
**Date:** [YYYY-MM-DD]
**Author:** [Name]

---

## Full Chain Traceability

| Business Obj | User Req | Functional Req | Design Element | Test Case | Status |
|-------------|----------|---------------|----------------|-----------|--------|
| [BO-ID] | [UC-ID / US-ID] | [FR-ID] | [Component] | [TC-ID] | Proposed/Approved/Implemented/Verified |

---

## Coverage Analysis

### Forward Coverage (Business Objectives -> Requirements)
| Business Objective | Requirements Count | Tested? | Coverage |
|-------------------|-------------------|---------|----------|
| [BO-1] | [N] | [Y/Partial/N] | [%] |

### Backward Coverage (Requirements -> Sources)
| Requirement | Has Source? | Has Test? |
|------------|-----------|-----------|
| [FR-ID] | Y/N | Y/N |

### Orphan Analysis
- **Requirements without sources:** [List any]
- **Requirements without tests:** [List any]
- **Test cases without requirements:** [List any]
- **Business objectives without requirements:** [List any]

---

## Impact Analysis Log

| Change Request | Requirement Changed | Affected Requirements | Affected Tests | Affected Design |
|---------------|--------------------|--------------------|----------------|----------------|
| [CR-ID] | [FR-ID] | [FR-IDs] | [TC-IDs] | [Components] |

---

## Metrics
- Total requirements: [N]
- Requirements with source trace: [N] ([%])
- Requirements with test trace: [N] ([%])
- Overall traceability coverage: [%]
```

## Notes
- Every requirement should have both a backward trace (source) and forward trace (test).
- Update this matrix whenever requirements change.
- Review orphan analysis at each milestone.
